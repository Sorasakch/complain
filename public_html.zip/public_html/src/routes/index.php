<?php
/* DO NOT EDIT FROM HERE */
$filename = __DIR__ . preg_replace('#(\?.*)$#', '', $_SERVER['REQUEST_URI']);
if (php_sapi_name() === 'cli-server' && is_file($filename)) {
    return false;
}
require_once 'src/routes/Bramus/Router/Router.php';
require_once 'src/controllers/auth.controller.php';
$router = new \Bramus\Router\Router(); // Create a Router
$router->setBasePath(ROOT);
/* 
DO NOT EDIT TO HERE

    หากเข้าถึงไฟล์ด้วย method GET ใช้คำสั่ง $router->get('/ชื่อ route', function() { CODE HERE })
    หากเข้าถึงไฟล์ด้วย method POST ใช้คำสั่ง $router->post('/ชื่อ route', function() { CODE HERE })
    หากเข้าถึงไฟล์ด้วย method PUT ใช้คำสั่ง $router->put('/ชื่อ route', function() { CODE HERE })
    หากเข้าถึงไฟล์ด้วย method DELETE ใช้คำสั่ง $router->delete('/ชื่อ route', function() { CODE HERE })
    หากเข้าถึงไฟล์โดยส่ง Paremeter ไปด้วย ใช้คำสั่ง $router->get,post,put,delete('/ชื่อ route/(\d+)', function($id) { CODE HERE })
    
    Role สำหรับคำสั่ง checkRoleAccess() ประกอบด้วย ['SuperAdmin', 'Admin', 'User']
*/

//ROUTE ปกติ
// $router->get('', function () {
//     isLogin(); // ตรวจสอบว่า login อยู่หรือไม่
//     require_once 'src/controllers/home.controller.php'; // เรียก Controller
//     require('src/views/home/home.php');  // เรียก View
// });

$router->get('', function () {
    require('src/views/public/index.php');
});

$router->get('/home', function () {
    isLogin();
    require_once 'src/controllers/home.controller.php';
    require('src/views/home/home.php');
});


//USERS
$router->get('/users', function () {
    isLogin();
    checkRoleAccess(['SuperAdmin', 'Admin']); // ตรวจสิทธิ์การเข้าถึง
    require_once 'src/controllers/users.controller.php';
    require('src/views/users/users.php');
});
$router->get('/userForm/(\d+)', function ($id) {
    isLogin();
    checkRoleAccess(['SuperAdmin']);
    require_once 'src/controllers/users.controller.php';
    getUserById($id);
});
$router->post('/userAdd', function () {
    isLogin();
    checkRoleAccess(['SuperAdmin']);
    require_once 'src/controllers/users.controller.php';
    addUser();
});
$router->post('/userUpdate/(\d+)', function ($id) {
    isLogin();
    checkRoleAccess(['SuperAdmin']);
    require_once 'src/controllers/users.controller.php';
    updateUser($id);
});
$router->delete('/userDelete/(\d+)', function ($id) {
    isLogin();
    checkRoleAccess(['SuperAdmin']);
    require_once 'src/controllers/users.controller.php';
    deleteUser($id);
});

//COMPLAINTS
$router->mount('/complaint', function () use ($router) {
    $router->get('', function () {
        isLogin();
        checkRoleAccess(['SuperAdmin', 'Admin']);
        require('src/controllers/complaint.controller.php');
        require('src/views/complaint/complaint.php');
    });
    $router->delete('/deletecomplaint/(\d+)', function ($id) {
        isLogin();
        checkRoleAccess(["SuperAdmin", 'Admin']);
        require('src/controllers/deletecomplaint.controller.php');
        echo json_encode(deletecomplaint($id));
    });
    $router->get('/editcomplian/(\d+)', function ($id) {
        isLogin();
        checkRoleAccess(["SuperAdmin", 'Admin']);
        require('src/controllers/editcomplaint.controller.php');
        getComplaintCaseById($id);
        // require('src/views/complaint/editcomplian.php');
    });
    $router->post('/complianUpdate/(\d+)', function ($id) {
        isLogin();
        checkRoleAccess(["SuperAdmin", 'Admin']);
        require_once 'src/controllers/editcomplaint.controller.php';
        ComplaintUpdate($id);
    });
});



// PUBLIC VIEWS
$router->mount('/public', function () use ($router) {
    $router->get('/makeComplaint', function () {
        require('src/views/public/makeComplaint.php');
    });
    $router->get('/trackComplaint', function () {
        require('src/views/public/trackComplaint.php');
    });
    $router->post('/makeComplaint', function () {
        require('src/controllers/complaint.controller.php');
        echo json_encode(makeComplaint());
    });
});

//LOGIN
$router->get('/login', function () {
    session_start();
    if (isset($_SESSION['is_logged_in'])) {
        header('Location: ' . ROOT . '/');
    }
    require('src/views/auth/login.php');
});
$router->post('/login', function () {
    login();
});
$router->get('/logout', function () {
    logout();
});

// Custom 404 Handler
// การตั้งค่าหน้า 404
$router->set404(function () {
    header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
    echo '404, route not found!';
});

// custom 404
$router->set404('/test(/.*)?', function () {
    header($_SERVER['SERVER_PROTOCOL'] . ' 404 Not Found');
    echo '<h1><mark>404, route not found!</mark></h1>';
});

$router->set404('/api(/.*)?', function () {
    header('HTTP/1.1 404 Not Found');
    header('Content-Type: application/json');
    $jsonArray = array();
    $jsonArray['status'] = "404";
    $jsonArray['status_text'] = "route not defined";

    echo json_encode($jsonArray);
});

//Run Router
$router->run();
