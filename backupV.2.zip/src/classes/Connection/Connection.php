<?php
/* 

!!EDIT WITH YOUR OWN RISK!! 

class Connection 
openConnection() เปิดการเชื่อมต่อกับฐานขอมูล
closeConnection() ปิดการเชื่อมต่อกับฐานขอมูล
showConnection() แสดงข้อมูลการเชื่อมต่อฐานขอมูล

*/

class Connection
{

    private static $conn;

    protected function openConnection()
    {
        if (!isset(self::$conn)) {
            if (DRIVER == 'MSSQL') {
                self::$conn = new PDO("sqlsrv:server=" . HOST . "; Database=" . DB, UID, PASSWORD);
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            } elseif (DRIVER == 'MySQL') {
                self::$conn = new PDO("mysql:host=" . HOST . ";dbname=" . DB, UID, PASSWORD);
                self::$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
            } else {
                return "ERROR: undefined or wrong driver";
            }
        }
        return self::$conn;
    }

    protected function closeConnection()
    {
        self::$conn = null;
    }

    protected function showConnection()
    {
        if (self::$conn) {
            echo "CONNECTED!!";
        } else {
            echo "FAIL TO CONNECT!!";
        }
    }
}
