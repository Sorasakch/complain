<footer class="footer">
    <div class="container">
        <nav class="float-left">
            <ul>
                <li>
                    <a href="https://www.moe.go.th" target="_blank">กระทรวงศึกษาธิการ</a>
                </li>
                <li>
                    <a href="https://www.ops.moe.go.th" target="_blank">สำนักงานปลัดกระทรวงศึกษาธิการ</a>
                </li>
                <li>
                    <a href="https://www.bict.moe.go.th" target="_blank">ศูนย์เทคโนโลยีสารสนเทศและการสื่อสาร</a>
                </li>
            </ul>
        </nav>
        <div class="copyright float-right">
            &copy;
            <script>
                document.write(new Date().getFullYear())
            </script>
            <a href="https://www.moe.go.th" target="blank">Ministry of Education, Thailand. All rights reserved</a>
        </div>
    </div>
</footer>