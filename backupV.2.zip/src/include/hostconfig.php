<?php
header('Access-Control-Allow-Origin: *');

define('DRIVER', 'MySQL'); // เลือกประเภทของฐานข้อมูล MySQL , MSSQL
define('HOST', 'localhost'); // ที่อยู่ของฐานข้อมูล
define('UID', 'root'); // ชื่อผู้ใช้ฐานข้อมูล
define('PASSWORD', ''); // รหัสผ่านฐานข้อมูล
define('DB', 'train_db6'); // ชื่อฐานข้อมูล

define('ROOT', ''); // ตำแหน่ง ROOT DIRECTORY
define('SYSNAME', 'ระบบรับเรื่องร้องเรียน ศปท.ศธ.'); // ชื่อระบบ
date_default_timezone_set('Asia/Bangkok'); // ตั้งเวลา

// Report all -1, error only 1, turn off 0
error_reporting(-1);
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
