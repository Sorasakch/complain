<div class="jumbotron" style="background-color: #eee;">
    <h1 class=" display-3"><?= SYSNAME; ?></h1>
    <p class="lead"><?= SYSNAME; ?></p>
    <hr class="my-2">
    <p>Created By BICT-MOE
        <script>
            document.write(new Date().getFullYear() + 543)
        </script>
    </p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="/"  role="button">หน้าแรก</a>
    </p>
</div>