
<!DOCTYPE html>

<style>
    #search_btn {
        background-color: #ec407a;
        color: #fff;
    }

    #show_div {

        width: 100%;
        padding: 50px 0;
        text-align: center;
        margin-top: 20px;
    }
</style>


<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-rose">
                <h4 class="card-title">
                    <img src="/public/images/notic.png" alt="" width="3%">
                    ติดตามเรื่องร้องเรียน
                </h4>
            </div>
            <div class="card-body">
                <form id="search_form" align="center">
                    <div class="form-group" align="center">
                        <input type="text" name="searchtoken" id="searchtoken" placeholder="กรอก TOKEN สำหรับค้นหา" style="width:900px;text-align:center;height:70px;font-size:xx-large;" pattern="[A-Za-z0-9]{7-20}">
                    </div>
                    <div align="center">
                    <button class="btn btn-success btn-lg"><i class="fa fa-search"></i> ค้นหา</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<div id="show_div" class="row d-none">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-rose">
                <h3 class="card-title">สถานะเรื่องร้องเรียน</h3>
            </div>

            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                                
                       <div id="div1">
                       <ul class="timeline timeline-simple">  
                            <li class="timeline-inverted">
                                <div class="timeline-badge info">
                                    <i class="material-icons">support_agent</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-info">รับเรื่องร้องเรียน</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>ระบบได้ทำการรับเรื่องร้องเรียนของท่านแล้ว</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> 
                                        <label style="text-align: right; color: #000;" id="complaint_date"></label>                                    </h6>
                                </div>
                            </li>
                            </ul>
                        </div>
     




                        <div id="div2">
                        <ul class="timeline timeline-simple">  
                                <li class="timeline-inverted">
                                <div class="timeline-badge info">
                                    <i class="material-icons">support_agent</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-info">รับเรื่องร้องเรียน</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>ระบบได้ทำการรับเรื่องร้องเรียนของท่านแล้ว</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> 
                                        <label style="text-align: right; color: #000;" id="complaint_date2"></label>                                    </h6>
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge primary">
                                    <i class="material-icons">gavel</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-primary">กำลังดำเนินการ</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>เรื่องร้องเรียนของท่านอยู่ระหว่างดำเนินการ</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> 
                                        <label style="text-align: right; color: #000;" id="receipt_date2"></label>                                    </h6>
                                </div>
                            </li>
                            </ul>
                            </div>


                            <?php
                            //  }

                            //  else if($value == "3") {
                
             
                            ?>
                            <div id="div3">
                            <ul class="timeline timeline-simple">  

                            <li class="timeline-inverted">
                                <div class="timeline-badge info">
                                    <i class="material-icons">support_agent</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-info">รับเรื่องร้องเรียน</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>ระบบได้ทำการรับเรื่องร้องเรียนของท่านแล้ว</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> 
                                        <label style="text-align: right; color: #000;" id="complaint_date3"></label>                                    </h6>
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge primary">
                                    <i class="material-icons">gavel</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-primary">กำลังดำเนินการ</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>เรื่องร้องเรียนของท่านอยู่ระหว่างดำเนินการ</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> 
                                        <label style="text-align: right; color: #000;" id="receipt_date3"></label>                                    </h6>
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge success">
                                    <i class="material-icons">task_alt</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-success">ดำเนินการเสร็จสิ้น</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>เรื่องร้องเรียนของท่านได้รับการดำเนินการแล้ว</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> 
                                        <label style="text-align: right; color: #000;" id="success_date3"></label>                                   
                                    </h6>
                                </div>
                            </li> 
                            </div>
                            </ul>

                            <div id="div4">
                 
                            
                            <p>คำร้องเรียนที่ท่านค้นหาไม่มีอยู่หรือถูกลบออกไปแล้ว</p>

            
           
                        </div>


                
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function searchTicketId() {
        $('#show_div').removeClass('d-none');
    }

    
    $("search_form").ready(() => {

        onSubmit()
     
    })

    function onSubmit() {
        $("#search_form").submit(function(e) {
            e.preventDefault()
            var formData = new FormData(this);
            axios
                .post('trackComplaint/trackComplaintsearch', formData)
                .then((res) => {
  
                    // swal.fire({
                    //         type: "success",
                    //         title: "สำเร็จ<br/>",
                    //         text: "บันทึกข้อมูลเรียบร้อยแล้ว"
                    //     })
                    //     .then(function() {
                            if(res.data == "9")
                            {
                                searchTicketId();
                                document.getElementById('div1').style.display = 'none';
                                document.getElementById('div2').style.display = 'none';
                                document.getElementById('div3').style.display = 'none';
                                document.getElementById('div4').style.display = 'block';
                                                
                            }
                            else{
                                searchTicketId();
                                appendData(res.data);
                            }
     
                             
                        // })
                })
        })
    }


    function appendData(data) {
        // data = JSON.stringify(data)
        data.forEach((item, index) => {



            if(item.status == "0")
            {
                $("#complaint_date").empty().text(item.complaint_date);
                document.getElementById('div1').style.display = 'block';
                document.getElementById('div2').style.display = 'none';
                document.getElementById('div3').style.display = 'none';
                document.getElementById('div4').style.display = 'none';

            }
            else if(item.status == "1")
            {

                $("#complaint_date2").empty().text(item.complaint_date);
                $("#receipt_date2").empty().text(item.receiptdate);
                document.getElementById('div1').style.display = 'none';
                document.getElementById('div2').style.display = 'block';
                document.getElementById('div3').style.display = 'none';
                document.getElementById('div4').style.display = 'none';

            }
            else if(item.status == "2")
            {
                $("#complaint_date3").empty().text(item.complaint_date);
                $("#receipt_date3").empty().text(item.receiptdate);
                $("#success_date3").empty().text(item.successdate);

                document.getElementById('div1').style.display = 'none';
                document.getElementById('div2').style.display = 'none';
                document.getElementById('div3').style.display = 'block';
                document.getElementById('div4').style.display = 'none';

            }
            else{
                document.getElementById('div1').style.display = 'none';
                document.getElementById('div2').style.display = 'none';
                document.getElementById('div3').style.display = 'none';
                document.getElementById('div4').style.display = 'block';
            }


            // var unsetId = $(this).attr('data-removeid');
            // Cookies.remove('status_value'+unsetId, { path: '' });
            // document.cookie = "status_value=" + item.status; 
        
        })
    }

</script>