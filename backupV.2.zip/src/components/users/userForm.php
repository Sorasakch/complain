<style>
    #roleSelect-error {
        margin-left: 10px;
    }

    .filter-option {
        color: #ffffff;
        font-size: 1.1em;
    }
</style>

<form id="userForm" class="form-horizontal">
    <div class="modal fade" id="userFormModal" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="modalTitle">เพิ่มผู้ใช้งาน</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <label class="col-sm-2 col-form-label">ชื่อ-สกุล</label>
                        <div class="col-sm-5">
                            <div class="form-group">
                                <input class="form-control" type="text" id="firstnameInput" name=" firstnameInput" placeholder="ชื่อ" required="true" />
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-group">
                                <input class="form-control" type="text" id="lastnameInput" name=" lastnameInput" placeholder="สกุล" required="true" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input class="form-control" type="text" id="emailInput" name=" emailInput" email="true" required="true" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">เบอร์โทรศัพท์</label>
                        <div class="col-sm-10">
                            <div class="form-group">
                                <input class="form-control" type="text" id="telInput" name=" telInput" number="true" placeholder="ใส่เฉพาะตัวเลขเท่านั้น" required="true" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">รหัสผ่าน</label>
                        <div class="col-sm-5">
                            <div class="form-group">
                                <input class="form-control" id="passwordInput" type="password" placeholder="ไม่ต่ำกว่า 8 ตัวอักษร" name="passwordInput" minLength="8" required=" true" />
                            </div>
                        </div>
                        <div class="col-sm-5">
                            <div class="form-group">
                                <input class="form-control" id="passwordInputConfirm" type="password" placeholder="กรอกรหัสผ่านอีกครั้ง" equalTo="#passwordInput" required="true" />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <label class="col-sm-2 col-form-label">บทบาท</label>
                        <div class="col-sm-8">
                            <div class="form-group">
                                <select class="selectpicker" id="roleSelect" name="roleInput" data-size="3" data-style="btn btn-rose btn-sm" title="กรุณาเลือกข้อมูล" required="true">
                                    <?php
                                    $roles = array(
                                        [
                                            "title" => "Super Admin",
                                            "value" => "SuperAdmin"
                                        ],
                                        [
                                            "title" => "Admin",
                                            "value" => "Admin"
                                        ],
                                        [
                                            "title" => "User",
                                            "value" => "User"
                                        ],
                                    );
                                    foreach ($roles as $key => $value) {
                                        if ($user[0]['role'] == $value['value']) {
                                            echo '<option value="' . $value['value'] . '" selected>' . $value['title'] . '</option>';
                                        } else {
                                            echo '<option value="' . $value['value'] . '">' . $value['title'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer text-center">
                    <div class="col-md-6 ml-auto mr-auto">
                        <button type="submit" class="btn btn-rose px-5">บันทึก</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<script>
    var userId = null;
    $(document).ready(() => {
        modalHidden()
        setFormValidation('#userForm');
        $("#roleSelect").change(() => {
            if ($("#roleSelect").val() == "SuperAdmin") {
                $('.filter-option-inner').text("SuperAdmin")
                $("#roleSelect").val("SuperAdmin");
            } else if ($("#roleSelect").val() == "Admin") {
                $('.filter-option-inner').text("Admin")
                $("#roleSelect").val("Admin");
            } else if ($("#roleSelect").val() == "User") {
                $('.filter-option-inner').text("User")
                $("#roleSelect").val("User");
            }
        });
    })

    $('#userForm').submit(function(e) {
        e.preventDefault();
        if ($(this).valid()) {
            var formData = new FormData($(this)[0]);
            if (userId) {
                axios
                    .post('userUpdate/' + userId, formData)
                    .then(res => {
                        if (res.data == "success") {
                            Swal.fire({
                                title: "สำเร็จ",
                                text: "บันทึกข้อมูลเรียบร้อย",
                                type: "success",
                                confirmButtonClass: "btn btn-success",
                                confirmButtonText: "ตกลง",
                            }).then(() => {
                                window.location.href = "users";
                            });
                        } else {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "บันทึกข้อมูลไม่สำเร็จ",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        }
                    })
            } else {
                axios
                    .post('userAdd', formData)
                    .then(res => {
                        console.log(res.data)
                        if (res.data === "success") {
                            Swal.fire({
                                title: "สำเร็จ",
                                text: "บันทึกข้อมูลเรียบร้อย",
                                type: "success",
                                confirmButtonClass: "btn btn-success",
                                confirmButtonText: "ตกลง",
                            }).then(() => {
                                window.location.href = "users";
                            });
                        } else if (res.data === "duplicate user") {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "email นี้มีผู้ใช้งานแล้ว",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        } else {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "บันทึกข้อมูลไม่สำเร็จ",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        }
                    })
            }
        }
    });

    function setFormValidation(formId) {
        $.validator.messages.required = "กรุณากรอกข้อมูล";
        $.validator.messages.email = "กรุณากรอกอีเมล์ให้ถูกต้อง";
        $.validator.messages.number = "ตัวเลขเท่านั้น";
        $.validator.messages.minlength = "กรุณากรอกข้อมูลอย่างน้อย 8 ตัวอักษร";
        $.validator.messages.equalTo = "รหัสผ่านไม่ตรงกัน";

        $(formId).validate({
            highlight: function(element) {
                $(element).closest('.form-group').removeClass('has-success').addClass('has-danger');
                $(element).closest('.form-check').removeClass('has-success').addClass('has-danger');
            },
            success: function(element) {
                $(element).closest('.form-group').removeClass('has-danger').addClass('has-success');
                $(element).closest('.form-check').removeClass('has-danger').addClass('has-success');
            },
            errorPlacement: function(error, element) {
                $(element).closest('.form-group').append(error);
            },
        });
    }

    function modalHidden() {
        $("#userFormModal").on('hidden.bs.modal', function() {
            $(this).modal('dispose')
            userId = null;
            $(this).data('bs.modal', null);
            $("#userForm").valid()
            $('#firstnameInput').val('')
            $('#lastnameInput').val('')
            $('#emailInput').val('')
            $('#passwordInput').val('')
            $('#passwordInputConfirm').val('')
            $('#telInput').val('')
        });
    }

    function userEditModalInit(id) {
        getUserById(id)
        userId = id
        $('#modalTitle').empty().text('แก้ไขผู้ใช้งาน')
    }

    function getUserById(id) {
        axios
            .get('userForm/' + id)
            .then(res => {
                setModalValue(res.data)
            })
    }

    function setModalValue(data) {
        $('#firstnameInput').val(data.firstname);
        $('#lastnameInput').val(data.lastname);
        $('#emailInput').val(data.email);
        $('#passwordInput').val(data.password);
        $('#passwordInputConfirm').val(data.password);
        $('#telInput').val(data.tel);
        $('#roleSelect').selectpicker('val', data.role);
    }
</script>