

<?php

$UI = new UI;
$header = ["#","ประเภผู้ร้องเรียน","ประเภทที่ร้องเรียน", "ชื่อเรื่อง" ,"บุคคล/หน่วยงาน", "วันที่ร้องเรียน","วันที่รับเรื่อง","สถานะ"];
$data = getCompliantCase();

?>

<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">gavel</i>
        </div>
        <h3 class="card-title">เรื่องร้องเรียน</h3>
    </div>
    <div class="card-body">

        <?php
        $UI->dataTable2($header, $data, "editcomplian", "deletecomplaint");
        ?>
    </div>
</div>


<!-- <script>
var statusBadge = $("tbody").children().children().last().prev().addClass('statusBadge')
var status = $("tbody").children().children().next().next().next().next().next().next().next().html()
console.log(status)

for (i=0; i < 50; i++) {
  

if(status == 0) {
    $(".statusBadge").html('<span class="badge badge-secondary">รอดำเนินการ</span>')
    
}else if(status == 1){

$(".statusBadge").html('<span class="badge badge-warning">กำลังดำเนินการ</span>')

}else if(status == 2){

$(".statusBadge").html('<span class="badge badge-success">สำเร็จ</span>')

}
}

</script> -->