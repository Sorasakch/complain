<style>
    #roleSelect-error {
        margin-left: 10px;
    }

    .filter-option {
        color: #ffffff;
        font-size: 1.1em;
    }
</style>

<style>
    .togglebutton label input[type=checkbox]:checked+.toggle {
        background-color: #e91e63;
    }
</style>
<h4 class="card-title">
                รายละเอียดเรื่องร้องเรียนต่อศูนย์ปฏิบัติการต่อต้านการทุจริต กระทรวงศึกษาธิการ 
            </h4>
<form id="complaintForm" class="form-horizontal">
    <div class="card mt-5">
        <div class="card-header card-header-rose">
            <h4 class="card-title">
                ข้อมูลผู้ร้องเรียน
            </h4>
        </div>
        <div class="card-body">
        <?php
            $Edittable = geEdittableById($id);
            ?>
            <div class="row">
                <label  style="text-align: right; color: #e73673;">เรื่องร้องเรียนที่ <?php echo ($id)  ?></label>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">ชื่อผู้แจ้ง</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="complainantName" name="complainantName" class="form-control" placeholder="ชื่อ นามสกุล" value="<?php echo ($id) ? $Edittable['fullname'] : '' ?>" readonly/>
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">อีเมล์</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="emailInput" name="emailInput" class="form-control" placeholder="e-mail" required="true" email="true"  value="<?php echo ($id) ? $Edittable['email'] : '' ?>" readonly/>
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">เบอร์ที่ติดต่อได้</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="telInput" name="telInput" class="form-control" value="<?php echo ($id) ? $Edittable['tel'] : '' ?>" readonly/>
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">ประเภทของผู้ร้องเรียน</label>
                <div class="col-sm-10">
                    <div class="form-group">
                    <input type="text" id="complainantTypeInput" name="complainantTypeInput" class="form-control" value="<?php echo ($id) ? $Edittable['responder'] : '' ?>"  readonly/>
                </div>
            </div>
            <!-- <div class="row">
                <label class="col-sm-2 col-form-label text-center">ต้องการปกปิดข้อมูลผู้ร้องเรียน</label>
                <div class="col-sm-10 togglebutton">
                    <label class="pt-3" id="dataLabel">
                        <input type="checkbox" id="dataSwitch">
                        <span class="toggle"></span>
                        <span id="switchText">ไม่ปกปิด</span>
                    </label>
                </div>
            </div>
        </div>
    </div> -->
    <div class="card mt-5">
        <div class="card-header card-header-rose">
            <h4 class="card-title">
                รายละเอียดการแจ้งเบาะแสการทุจริต และ คุณธรรม จริยธรรม
            </h4>
        </div>
        <div class="card-body">

            <div class="row">
                <label class="col-sm-2 col-form-label text-center">ประเภทเรื่องร้องเรียน</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="complainanttopic" name="complainanttopic" class="form-control" value="<?php echo ($id) ? $Edittable['type'] : '' ?>"  readonly/>
                    </div>
                </div>
            </div>

            <div class="row">
                <label class="col-sm-2 col-form-label text-center">หัวข้อเรื่อง</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="complaintCaseTitleInput" name="complaintCaseTitleInput" class="form-control" placeholder=""  value="<?php echo ($id) ? $Edittable['title'] : '' ?>"  readonly/>
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center"  required="true">รายละเอียดเรื่องร้องเรียน</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <textarea id="complaintDetailInput" name="complaintDetailInput" class="form-control" rows=" 3"   readonly/><?php echo ($id) ? $Edittable['detail'] : '' ?></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center"  required="true">บุคคล/หน่วยงานที่ต้องการร้องเรียน *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="defenderInput" name="defenderInput" class="form-control" placeholder="ชื่อบุคคล / หน่วยงาน" value="<?php echo ($id) ? $Edittable['defender'] : '' ?>" readonly/>
                    </div>
                </div>
            </div>
            <!-- <div class="row">
                <label class="col-sm-2 col-form-label text-center">เอกสารประกอบการร้องเรียน *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <span class="btn btn-rose">
                            <input type="file" id="attacthmentInput" name="attacthmentInput" class="form-control-file" placeholder="" aria-describedby="fileHelpId">
                            เลือกไฟล์
                        </span>
                    </div>
                </div>
            </div> -->
        </div>
        <div class="card-footer">
            <div class="col-md-12 text-center">
                <button class="btn btn-warning btn-lg me-5"  onClick="refreshPage()">ยกเลิก</button>
                <button class="btn btn-success btn-lg">ส่งเรื่อง</button>
            </div>
        </div>
    </div>
</form>

<script>
function refreshPage(){
    window.location.reload();
} 


    $("document").ready(() => {
        dataSwitch()
        onSubmit()
    })

    function onSubmit() {
        $("#complaintForm").submit(function(e) {
            e.preventDefault()
            // $(".btn").prop("disabled", true)
            var formData = new FormData(this);
            var dt = new Date();
            var time = dt.getHours() + "" + dt.getMinutes() + "" + dt.getSeconds();
            var token = makeid(2) + time
            formData.append('token', token)
            formData.append('responder', '')
            axios
                .post('makeComplaint', formData)
                .then((res) => {
                    console.log(res.data)
                    swal.fire({
                            type: "success",
                            title: "บันทึกข้อมูลเรียบร้อยแล้ว<br/>TOKEN: " + token,
                            text: "กรุณาจัดเก็บ TOKEN ของท่านเพื่อติดตามเรื่องร้องเรียน"
                        })
                        .then(function() {
                            // window.location.href = "/public/home";
                        })
                })
        })
    }

    function dataSwitch() {
        $("#dataSwitch").change(() => {
            if ($("#dataSwitch").prop("checked") == true) {
                $("#dataSwitch").prop("checked", true)
                $("#switchText").text('ปกปิด')
            } else {
                $("#dataSwitch").attr("checked", false)
                $("#switchText").text('ไม่ปกปิด')
            }
        })
    }

    function makeid(length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() *
                charactersLength));
        }
        return result;
    }
</script>

<script>
    var userId = null;
    $(document).ready(() => {
        modalHidden()
        setFormValidation('#userForm');
        $("#roleSelect").change(() => {
            if ($("#roleSelect").val() == "SuperAdmin") {
                $('.filter-option-inner').text("SuperAdmin")
                $("#roleSelect").val("SuperAdmin");
            } else if ($("#roleSelect").val() == "Admin") {
                $('.filter-option-inner').text("Admin")
                $("#roleSelect").val("Admin");
            } else if ($("#roleSelect").val() == "User") {
                $('.filter-option-inner').text("User")
                $("#roleSelect").val("User");
            }
        });
    })

    $('#userForm').submit(function(e) {
        e.preventDefault();
        if ($(this).valid()) {
            var formData = new FormData($(this)[0]);
            if (userId) {
                axios
                    .post('userUpdate/' + userId, formData)
                    .then(res => {
                        if (res.data == "success") {
                            Swal.fire({
                                title: "สำเร็จ",
                                text: "บันทึกข้อมูลเรียบร้อย",
                                type: "success",
                                confirmButtonClass: "btn btn-success",
                                confirmButtonText: "ตกลง",
                            }).then(() => {
                                window.location.href = "users";
                            });
                        } else {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "บันทึกข้อมูลไม่สำเร็จ",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        }
                    })
            } else {
                axios
                    .post('userAdd', formData)
                    .then(res => {
                        console.log(res.data)
                        if (res.data === "success") {
                            Swal.fire({
                                title: "สำเร็จ",
                                text: "บันทึกข้อมูลเรียบร้อย",
                                type: "success",
                                confirmButtonClass: "btn btn-success",
                                confirmButtonText: "ตกลง",
                            }).then(() => {
                                window.location.href = "users";
                            });
                        } else if (res.data === "duplicate user") {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "email นี้มีผู้ใช้งานแล้ว",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        } else {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "บันทึกข้อมูลไม่สำเร็จ",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        }
                    })
            }
        }
    });

    function setFormValidation(formId) {
        $.validator.messages.required = "กรุณากรอกข้อมูล";
        $.validator.messages.email = "กรุณากรอกอีเมล์ให้ถูกต้อง";
        $.validator.messages.number = "ตัวเลขเท่านั้น";
        $.validator.messages.minlength = "กรุณากรอกข้อมูลอย่างน้อย 8 ตัวอักษร";
        $.validator.messages.equalTo = "รหัสผ่านไม่ตรงกัน";

        $(formId).validate({
            highlight: function(element) {
                $(element).closest('.form-group').removeClass('has-success').addClass('has-danger');
                $(element).closest('.form-check').removeClass('has-success').addClass('has-danger');
            },
            success: function(element) {
                $(element).closest('.form-group').removeClass('has-danger').addClass('has-success');
                $(element).closest('.form-check').removeClass('has-danger').addClass('has-success');
            },
            errorPlacement: function(error, element) {
                $(element).closest('.form-group').append(error);
            },
        });
    }

    function modalHidden() {
        $("#userFormModal").on('hidden.bs.modal', function() {
            $(this).modal('dispose')
            userId = null;
            $(this).data('bs.modal', null);
            $("#userForm").valid()
            $('#firstnameInput').val('')
            $('#lastnameInput').val('')
            $('#emailInput').val('')
            $('#passwordInput').val('')
            $('#passwordInputConfirm').val('')
            $('#telInput').val('')
        });
    }

    function userEditModalInit(id) {
        getUserById(id)
        userId = id
        $('#modalTitle').empty().text('แก้ไขผู้ใช้งาน')
    }

    function getUserById(id) {
        axios
            .get('userForm/' + id)
            .then(res => {
                setModalValue(res.data)
            })
    }

    function setModalValue(data) {
        $('#firstnameInput').val(data.firstname);
        $('#lastnameInput').val(data.lastname);
        $('#emailInput').val(data.email);
        $('#passwordInput').val(data.password);
        $('#passwordInputConfirm').val(data.password);
        $('#telInput').val(data.tel);
        $('#roleSelect').selectpicker('val', data.role);
    }
</script>