<?php
$getData = getmemoedit();
?>


<div class="memo"><b>ตัวอย่างประกาศ</b></div>
<div class="card card-stats">
    <div class="card-header card-header-rose card-header-icon">
           <marquee style="cursor:pointer;margin:10px; color: <?php print_r($getData[0]['color']);?>" 
            class="notice" onmouseover="this.stop()" onmouseout="this.start()" 
            scrollamount="8" >
                  <?php print_r($getData[0]['announcement']);?> 
            </marquee>
                  </div>
                </div>


<div class="card">
    <div class="card-header card-header-rose card-header-icon">
        <div class="card-icon">
            <i class="material-icons">campaign</i>
        </div>
        <h3 class="card-title">ประกาศ</h3>
    </div>
    <form id="complaintmemo" class="form-horizontal">
    <div class="card-body">
    <div class="row">
                <label class="col-sm-2 col-form-label text-center"  required="true">รายละเอียดที่ต้องการประกาศ</label>
                <div class="col-sm-10">
                <div class="form-group">
                        <textarea id="memoDetailInput" name="memoDetailInput" class="form-control" rows=" 3" placeholder="ระบุเรื่องที่ต้องการประกาศ" required> <?php print_r($getData[0]['announcement']);?> </textarea>
                </div>
               </div>
               <label class="col-sm-2 col-form-label text-center"  required="true">เปลี่ยนสีประกาศ</label>
                <div class="col-sm-10">
                <div class="form-group">
                <input type="color" id="colorpicker" name="colorpicker" value="<?php print_r($getData[0]['color']);?>">

                </div>
               </div>

    </div>
    <div class="card-footer">
            <div class="col-md-12 text-center">
                <button class="btn btn-success btn-lg">บันทึก</button>
            </div>
        </div>
</div>
</form>


<script>
$("#colorpicker").change(function(){
  $("marquee").css('color', $(this).val());
  var color = $(this).val();
  document.getElementById("colorpicker").setAttribute('value',color);


});




function refreshPage(){
    window.location.reload();
} 


    $("complaintmemo").ready(() => {
        onSubmit()
     
    })

    function onSubmit() {
        $("#complaintmemo").submit(function(e) {
            e.preventDefault()
            var formData = new FormData(this);
            axios
                .post('editmemo/memoUpdate/', formData)
                .then((res) => {
                    console.log(res.data)
                    swal.fire({
                            type: "success",
                            title: "สำเร็จ<br/>",
                            text: "บันทึกข้อมูลเรียบร้อยแล้ว"
                        })
                        .then(function() {
                             window.location.href = "/editmemo";
                        })
                })
        })
    }




</script>