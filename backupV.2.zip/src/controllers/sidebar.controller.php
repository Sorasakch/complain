<?php


function navList() //แก้ไข เมนูหลัก
{
    return $navList = [
        array( // หากต้องการเพิ่มเมนู ให้ copy ส่วน array() ทั้งหมดไปต่อด้านล่าง
            "name" => "หน้าแรก",  //ชื่อเมนู
            "link" => ROOT . "/home", //ลิงค์ ระบุให้ตรงกับ router
            "logo" => "home", //รูปภาพเมนู
            "role" => ["SuperAdmin", "Admin", "User"], //สิทธิ์ที่สามารถเข้าได้
            "active" => setActive("home"), //บอกสถานะเมนูที่ใช้งาน ให้ใส่ตรงกับ ลิงค์ของเมนู 
            "items" => [], //รายการย่อยของเมนู ถ้าไม่มีให้ใส่ []
        ),
        array(
            "name" => "หน้าแรก",
            "link" => ROOT . "/",
            "logo" => "home",
            "role" => "",
            "active" => setActive("home"),
            "items" => [],
        ),
        array(
            "name" => "ประกาศ",
            "link" => ROOT . "/editmemo",
            "logo" => "campaign",
            "role" => ["SuperAdmin", "Admin"],
            "active" => setActive("editmemo"),
            "items" => [],
        ),
        array(
            "name" => "เรื่องร้องเรียน",
            "link" => ROOT . "/complaint",
            "logo" => "gavel",
            "role" => ["SuperAdmin", "Admin"],
            "active" => setActive("complaint"),
            "items" => [],
        ),

        array(
            "name" => "เจ้าหน้าที่",
            "link" => ROOT . "/users",
            "logo" => "people",
            "role" => ["SuperAdmin", "Admin"],
            "active" => setActive("users"),
            "items" => [],
        ),
        // array(
        //     "name" => "Sub Menu",
        //     "link" => "",
        //     "logo" => "works",
        //     "role" => ["SuperAdmin", "Admin"],
        //     "active" => "",
        //     "items" => [
        //         array(
        //             "name" => "Sub Menu 1", //ชื่อเมนูย่อย
        //             "link" => ROOT . "/subroute/subroute-1", //ลิงค์ย่อย ระบุให้ตรงกับ router
        //             "logo" => "lists",
        //             "active" => setActive("subroute-1"),
        //         ),
        //         array(
        //             "name" => "Sub Menu 2",
        //             "link" => ROOT . "/subroute/subroute-2",
        //             "logo" => "lists",
        //             "active" => setActive("subroute-2"),
        //         ),
        //     ]
        // ),
        array(
            "name" => "pubic View",
            "link" => ROOT . "/public/home",
            "logo" => "key",
            "role" => "",
            "active" => setActive("home"),
            "items" => []
        ),
        array(
            "name" => "Logout",
            "link" => ROOT . "/logout",
            "logo" => "key",
            "role" => ["SuperAdmin", "Admin", "User"],
            "active" => "",
            "items" => []
        )
    ];
}

function sideBarConfig() // ปรับแต่งเมนูหลัก
{
    return $navConf = [
        "sidebarTitle" => "MOE", //ชื่อเมนูหลัก
        "navColor" => "black", //สีของเมนูหลัก
        "dataColor" => "rose", // สีของรายการ "rose" | "purple | azure | green | orange | danger" 
        "dataImg" => ROOT . "/assets/img/moe-building-vert.jpg" //รูปภาพหลัก
    ];
}

function showNav() //เรียกใช้งานเมนู
{
    foreach (navList() as $key => $val) { //วนลูปแสดงเมนูหลัก
        if (session_status() === PHP_SESSION_NONE) { // ถ้าไม่มีการล็อกอิน
            if ($val['role'] == "") { // ถ้าค่าของ role เป็นค่าว่าง
                showMenu($val); // แสดงเมนูส่วน Public
            }
        } else if ($val['role'] != "") { // ถ้ามีการล็อกอิน
            showMenu($val); // แสดงเมนูส่วน Private
        }
    }
}

function setActive($path) // แสดงเมนูที่ใช้งานอยู่
{
    $url = explode('/', $_SERVER['REQUEST_URI']); // ดึงค่า URL ที่กำลังใช้งานอยู่และแยกค่า URL เป็นค่าแต่ละตัว โดยแบ่งด้วย '/'
    $url = end($url); // แสดงค่าตัวสุดท้ายของ URL
    if ($url == $path) { // ถ้าค่าของ URL ตรงกับค่าของ path
        return 'active'; // แสดงค่า active
    } else {
        return '';
    }
}

function showMenu($val) // แสดงเมนูโดยรับค่า $val มาแสดง
{
    if ($val['items'] == []) {
        echo '
                <li class="nav-item ' . $val['active'] . '">
                    <a class="nav-link" href="' . $val['link'] . '">
                        <i class="material-icons">' . $val['logo'] . '</i>
                        <p>' . $val['name'] . '</p>
                    </a>
                </li>';
    } else {
        $show = '';
        for ($i = 0; $i < sizeof($val['items']); $i++) {
            if ($val['items'][$i]['active'] == 'active') {
                $show = 'show';
            }
        }
        echo '
                <li class="nav-item ">
                    <a class="nav-link" data-toggle="collapse" href="#' . $val['name'] . '">
                        <i class="material-icons">' . $val['logo'] . '</i>
                        <p> ' . $val['name'] . '
                            <b class="caret"></b>
                        </p>
                    </a>
                    <div class="collapse ' . $show . '" id="' . $val['name'] . '">
                    <ul class="nav">';
        foreach ($val['items'] as $key1 => $val1) {
            echo '
                    <li class="nav-item ' . $val1['active'] . '">
                    <a class="nav-link" href="' . $val1['link'] . '">
                        <i class="material-icons">' . $val1['logo'] . '</i>
                        <span class="sidebar-normal"> ' . $val1['name'] . ' </span>
                    </a>
                    </li>';
        }
        echo '
                    </ul>
                    </div>
                </li>';
    }
}
