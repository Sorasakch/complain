<?php

function pageTitle()
{
    return 'ผู้ใช้งาน';
}

function addUser()
{
    $user = new Users;
    echo $user->addUser();
}

function updateUser($id)
{
    $user = new Users;
    echo $user->updateUser($id);
}

function getUserById($id)
{
    $user = new Users;
    echo json_encode($user->getUserById($id));
}

function getCustomUsersView()
{
    $user = new Users;
    return $user->getShowUser();
}

function deleteUser($id)
{
    $user = new Users;
    echo $user->deleteUser($id);
}
