<?php

function pageTitle()
{
    return 'ผู้ใช้งาน';
}


function setMemoData()
{
    return array(
        'announcement' => $_POST['memoDetailInput'],
        'color' => $_POST['colorpicker']
    );
}

function getmemoedit()
{
    try {
        $sql = "SELECT announcement , color
        FROM announcement_table
        WHERE id = 1 ";
        $query = new Query;
        $result = $query->execute($sql);
        return $result;
    } catch (\PDOException $e) {
        return "ERROR: " . $e->getMessage();
    }
}


function memoUpdate()
{
    try {
        $memo = setMemoData();
        $sql = "UPDATE announcement_table SET announcement = '$memo[announcement]' , color = '$memo[color]' WHERE id = 1";
        $query = new Query;
        $result = $query->execute($sql);
        return $result;
    } catch (\PDOException $e) {
        return "ERROR: " . $e->getMessage();
    }
}


?>