<?php

function getCompliantCase()
{
    $compliant = new Complaint;
    return $compliant->getComplaintCase();
}

function makeComplaint()
{

    $complaint = new Complaint;
    return $complaint->makeComplaint();


    // try {
    //     $complaint = new Complaint;
    //     print_r(json_encode($complaint->makeComplaint()));
    // } catch (Exception $e) {
    //     return json_encode($e->getmessage());
    // }
}

function setsearchData()
{
    return array(
        'token' => $_POST['searchtoken']
    );
}



function tracksearch()
{
    try {
        $search = setsearchData();
        $sql = "SELECT token,status,complaint_date,
        receiptdate, successdate
        FROM complaint_case WHERE token = '$search[token]'";        
        $query = new Query;
        $result = $query->execute($sql);
        if($result == null)
        {
            $result = "9";
            return $result;
        }
        else{
            return $result;

        }
  
    } catch (\PDOException $e) {
        return "ERROR: " . $e->getMessage();
    }
  
}
