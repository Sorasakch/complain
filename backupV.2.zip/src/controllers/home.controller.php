<?php

function pageTitle() {
    return 'HOME';
}

function getmemo()
{       
            
    $sql = "SELECT 	announcement , color
    FROM announcement_table ";
    $query = new Query;
    $result = $query->execute($sql);
    return $result;

}
?>

