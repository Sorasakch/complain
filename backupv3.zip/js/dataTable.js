$("document").ready(function () {
    if ($("#datatables")) {
        $("#datatables").DataTable({
            responsive: true,
            order: [[0, 'desc']]
        })
    }
})
function editBtn(route, id) {
    var currentPath = location.pathname.substring(location.pathname.lastIndexOf('/') + 1)
    window.location.href = `${currentPath}/${route}/${id}`
}
function delBtn(route, id) {
    Swal.fire({
        type: 'warning',
        title: 'คุณต้องการลบข้อมูล',
        showCancelButton: true,
        focusCancel: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        cancelButtonText: 'ยกเลิก',
        confirmButtonText: 'ยืนยัน'
    }).then((result) => {
        if (result.value) {
            var currentPath = location.pathname.substring(location.pathname.lastIndexOf('/') + 1)
            console.log(`${currentPath}/${route}/${id}`)
            axios
                .delete(`${currentPath}/${route}/${id}`)
                .then(res => {
                    if (res.data == "success") {
                        Swal.fire({
                            type: "success",
                            title: "ลบข้อมูลสำเร็จ",
                            confirmButtonText: "ตกลง",
                            onClose: () => {
                                location.reload()
                            }
                        })
                    } else {
                        Swal.fire({
                            type: "error",
                            title: "ไม่สามารถลบข้อมูลได้",
                            text: "กรุณาติดต่อผู้ดูแลระบบ",
                            confirmButtonText: "ตกลง",
                        })
                    }
                })
        }
    })
}