<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #fff;
  box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
  padding: 10px;
}


.topnav a {
  float: left;
  display: block;
  color: #767676;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 14px;
  
}

.headweb {
  float: left;
  display: block;
  color: #767676;
  text-align: center;
  padding: 18px 16px;
  text-decoration: none;
  font-size: 24px; 
  
}

.topnav a:hover {
  background-color: #fff;
  color: #434242;
}

.topnav a.active {
  /* background-color: #04AA6D;
  color: white; */
}

.topnav .icon {
  display: none;
}

@media screen and (max-width: 600px) {
  .topnav a:not(:first-child) {display: none;}
  .topnav a.icon {
    float: right;
    display: block;
  }
}

@media screen and (max-width: 600px) {
  .topnav.responsive {position: relative;}
  .topnav.responsive .icon {
    position: absolute;
    right: 0;
    top: 0;
  }
  .topnav.responsive a {
    float: none;
    display: block;
    text-align: left;
  }
}
</style>
</head>
<body>

<div class="topnav" id="myTopnav">
  
  <a class="headweb" style="
    font-size: 20px;">   <?= SYSNAME; ?>
 </a>
  <a href="/">หน้าแรก</a>
  <a href="/public/makeComplaint">ร้องเรียนการทุจริต</a>
  <a href="/public/trackComplaint">ติดตามเรื่องร้องเรียน</a>
  <a href="/public/checktoken">ตรวจสอบรหัสติดตามเรื่องร้องเรียน</a>
  <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i>
  </a>
</div>
<br>


<script>
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}
</script>

</body>
</html>










 <!-- <style>
    .navbar-nav.navbar-center {
        position: absolute;
        left: 50%;
        transform: translatex(-50%);
    }

</style> -->
<!-- 
 <nav class="navbar navbar-expand-sm navbar-light bg-light">
    <div class="container">
        <a class="navbar-brand" href="/"> 
             <?= SYSNAME; ?> 
         </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav navbar-center">
                <li class="nav-item active">
                    <a class="nav-link" href="/">
                        หน้าแรก
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/public/makeComplaint">
                        ร้องเรียน
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/public/trackComplaint">
                        ติดตามเรื่องร้องเรียน
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="/public/checktoken">
                        ตรวจสอบเลขที่ติดตามเรื่องร้องเรียน
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav> -->