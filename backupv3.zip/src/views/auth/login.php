<?php

function loginPageConf() // ปรับแต่งหน้า Login
{
    return [
        "bgImg" => ROOT . "/assets/img/moe-building.jpg", // รูปภาพพื้นหลังหน้า Login
        "cardHeaderColor" => "card-header-rose", // สีของ Header ของ Card
        "cardHeaderImg" => ROOT . '/assets/img/moe_logo.png', // Logo ของ Card Header
        "cardHeaderTitle" => SYSNAME, // ชื่อระบบ
        "loginBtnTitle" => "เข้าสู่ระบบ", // ชื่อปุ่ม
        "btnColor" => "btn-rose", // สีปุ่ม
    ];
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <?php include "src/views/layout/headerScript.php"; ?>
    <title><?php echo SYSNAME; ?></title>
</head>

<body class="off-canvas-sidebar">
    <div class="wrapper wrapper-full-page">
        <div class="page-header login-page header-filter" filter-color="black" style="background-image: url(<?php echo loginPageconf()['bgImg']; ?>); background-size: cover; background-position: top center;">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-8 ml-auto mr-auto">
                        <!-- FORM START HERE-->
                        <?php require "src/components/auth/loginForm.php"; ?>
                    </div>
                </div>
            </div>
            <?php include "src/views/layout/footer.php"; ?>
        </div>
    </div>
    <?php include "src/views/layout/footerScript.php"; ?>
</body>

</html>