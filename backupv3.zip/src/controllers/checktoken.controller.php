<?php


function setsearchData()
{
    return array(
        'tel' => $_POST['searchtoken']
    );
}

function tokensearch()
{
    try {
        $search = setsearchData();
        $sql = "SELECT cc.token,cc.complaint_date
        FROM complaint_case cc, complainant c  
        WHERE (cc.id = c.id and cc.status != 9) and ( c.tel = '$search[tel]' or c.email = '$search[tel]')";        
        $query = new Query;
        $result = $query->execute($sql);
        if($result == null)
        {
            $result = "0";
            return $result;
        }
        else{
            return $result;

        }
  
    } catch (\PDOException $e) {
        return "ERROR: " . $e->getMessage();
    }
  
}