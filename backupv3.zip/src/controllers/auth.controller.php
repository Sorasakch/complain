<?php

// ฟังก์ชั่นสำหรับตรวจสอบว่ามีผู้ใช้อยู่ในระบบหรือไม่
function isLogin()
{
    session_start();
    if (!isset($_SESSION['is_logged_in'])) { // ถ้าไม่มีการล็อกอิน
        header('Location: ' . ROOT . '/login'); // ส่งกลับไปหน้า login
    }
}

// ฟังก์ชั่นสำหรับตรวจสอบสิทธิ์การเข้าใช้งาน
function checkRoleAccess($roleArr)
{
    if (empty(in_array(getRole(), $roleArr))) { // หากไม่มีสิทธิ์ในการเข้าใช้งาน
        header('Location: ' . ROOT . '/login'); // ส่งกลับไปหน้า login
    }
}

// ฟังก์ชั่นสำหรับทำการ Login
function login()
{
    $auth = new Auth; // สร้าง Instance ของ Auth Class
    $result = $auth->doLogin($_POST['emailInput'], $_POST['passwordInput']); //เรียกใช้งานเมธอด doLogin ของ Auth Class
    echo $result;
}

// ฟังก์ชั่นสำหรับทำการ Logout
function logout()
{
    $auth = new Auth; // สร้าง Instance ของ Auth Class
    $auth->dologout(); //เรียกใช้งานเมธอด dologout ของ Auth Class
}

// ฟังก์ชั่นสำหรับดึงข้อมูลบทบาท
function getRole()
{
    $role = new Auth;
    return $role->getCheckRole();
}
