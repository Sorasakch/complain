<?php

function pageTitle()
{
    return 'ผู้ใช้งาน';
}




function deletecomplaint($id)
{



    try {
        $sql = "UPDATE complaint_case SET status = 9 
        WHERE id = $id ";

        $sql2 = "UPDATE complainant SET status = 9
        WHERE id = $id";


        $query = new Query();
        $query->execute($sql);
        $query->execute($sql2);
        return "success";
    } catch (\PDOException $e) {
        return "Error: " . $e->getMessage();
    }
}