<?php

function pageTitle()
{
    return 'ผู้ใช้งาน';
}

function getComplaintCaseById($id)
{
    $complaint = new Editcomplaint;
    echo json_encode($complaint->getComplaintCaseById($id));
}

function getEdittable()
{
    $Edittable = new Editcomplaint;
    return $Edittable->getEdittable();
}
function geEdittableById($id)
{
    $Edittable = new Editcomplaint;
    return $Edittable->getEdittableById($id)[0];
}

function ComplaintUpdate($id)
{
    $Edittable = new Editcomplaint;
    echo json_encode( $Edittable->ComplaintUpdate($id));
}

function deletefruit($id)
{
    $Edittable = new Editcomplaint;
    return $Edittable->deletefruit($id);
}
