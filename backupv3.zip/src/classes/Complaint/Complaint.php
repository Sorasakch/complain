<?php

class Complaint
{

    private function setComplaintInput()
    {
        return array(
            'fullname' => $_POST['complainantName'],
            'email' => $_POST['emailInput'],
            'tel' => $_POST['telInput'],
            // 'complainantType' => $_POST['complainantTypeInput'],
            'complaintType' => $_POST['complainanttopic'],
            'title' => $_POST['complaintCaseTitleInput'],
            'detail' => $_POST['complaintDetailInput'],
            'defender' => $_POST['defenderInput'],
            'token' => $_POST['token'],
            'responder' => $_POST['complainantTypeInput']
            // $file => $_POST['attacthmentInput']
        );
    }

    public function getComplaintCase()
    {
        return $this->setComplaintCase();
    }

    private function setComplaintCase()
    {
        try {
            $sql = "SELECT id,responder,type,
                title, defender, complaint_date, receiptdate, status
                FROM complaint_case WHERE status != 9";
            $query = new Query;
            $result = $query->execute($sql);
            return $result;
        } catch (\PDOException $e) {
            return "ERROR: " . $e->getMessage();
        }
    }

    public function makeComplaint()
    {
        return $this->doInsertComplaintCase();
    }

    private function doInsertComplaintCase()
    {

       
            $complaintCase = $this->setComplaintInput();
            $sql = "INSERT INTO complaint_case (title, type, detail, token , defender,responder, status , receiptdate) 
                VALUES ('$complaintCase[title]', 
                '$complaintCase[complaintType]', 
                '$complaintCase[detail]', 
                '$complaintCase[token]',
                '$complaintCase[defender]',
                '$complaintCase[responder]', 
                '0',
                null
                )";  

               $sql2 = "INSERT INTO complainant (fullname,responder, email, tel,status) 
               VALUES ('$complaintCase[fullname]', 
               '$complaintCase[responder]', 
               '$complaintCase[email]', 
               '$complaintCase[tel]',
               '0')";  
                
            try {
                $query = new Query();
                $query->execute($sql);
                $query->execute($sql2);
                return "success";
            } catch (\PDOException $e) {
                return "Error: " . $e->getMessage();
            }    



       


    //     $complaintCase = $this->setComplaintInput();
    //     return $complaintCase;
    //     $sql = "INSERT INTO complaint_case(
    //             'title',
    //             'type',
    //             'complainant_id',
    //             'detail',
    //             'defender',
    //             'remark',
    //             'token',
    //             'open_complaintant_data',
    //             'status',
    //             'responder',
    //             'created_date',
    //             'updated_date'
    //             )
    //             VALUES(
    //                 $complaintCase['title'],
    //                 '1',
    //                 $complaintCase['detail'],
    //                 $complaintCase['defender'],
    //                 '',
    //                 $complaintCase['token'],
    //                 '1', 
    //                 '1',
    //                 $complaintCase['responder'],
    //             )";
    }
}
