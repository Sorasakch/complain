<?php

class Editcomplaint
{
    public $id;

    public function getEdittableId()
    {
        return $this->id;
    }

    private function setEdittableData()
    {
        return array(
            'fullname' => $_POST['complainantName'],
            'email' => $_POST['emailInput'],
            'tel' => $_POST['telInput'],
            // 'complainantType' => $_POST['complainantTypeInput'],
            'complaintType' => $_POST['complainanttopic'],
            'title' => $_POST['complaintCaseTitleInput'],
            'detail' => $_POST['complaintDetailInput'],
            'defender' => $_POST['defenderInput'],
            // 'token' => $_POST['token'],
            'responder' => $_POST['complainantTypeInput'],
            'status' => $_POST['statusInput'],
            'name_officer' => $_POST['name_officer']
            // $file => $_POST['attacthmentInput']
        );
    }

    public function getComplaintCaseById($id)
    {
        return $this->setComplaintCaseById($id);
    }

    private function setComplaintCaseById($id)
    {
        try {
            $sql = "SELECT c.id , c.fullname, c.responder, c.email, 
            c.tel, c.status ,cc.type,cc.title,cc.detail
            ,cc.defender,cc.complaint_date,cc.token, cc.attachment  , cc.successdate , cc.officername ,cc.officername_succ
            FROM complainant c,complaint_case cc
            WHERE c.id = '$id' && cc.id = '$id' ";
            $query = new Query;
            $result = $query->execute($sql);
            return $result[0];
        } catch (\PDOException $e) {
            return "ERROR: " . $e->getMessage();
        }
    }


    /// 
    public function ComplaintUpdate($id)
    {
        return $this->doComplaintUpdate($id);
    }

    private function doComplaintUpdate($id)
    {
        
        try {
            $com = $this->setEdittableData();
            
            $checkstatus = $com['status'];
            $name1 = $_SESSION["firstname"];
            $name2 = $_SESSION["lastname"];
            $name3 = $name1 ." ". $name2;

            if($checkstatus == 2)
            {

               
            $sql = "UPDATE complaint_case 
                      SET status = '$com[status]', successdate = CURRENT_TIMESTAMP , officername_succ = '$name3'  WHERE id = $id";
            
            }
            else
            {

                $sql = "UPDATE complaint_case 
                SET status = '$com[status]', receiptdate = CURRENT_TIMESTAMP , officername = '$name3'  WHERE id = $id";
            }


            $sql2 = "UPDATE complainant 
            SET status = '$com[status]' WHERE id = $id";

            $query = new Query();
            $query->execute($sql);
            $query->execute($sql2);
            return "success";
        } catch (\PDOException $e) {
            return $e->getMessage();
        }
    }


//     private function sqllog($sqlinput)
// {
//     $sqlinput = $string = str_replace("'","\'",$sqlinput);
//      $sql = "INSERT INTO query (query) values ('".$sqlinput."')";
//      try {
//         $query = new Query;
//         $result = $query->execute($sql);
        
//     } catch (\PDOException $e) {
//         return "ERROR: " . $e->getMessage();
//     }

// }


    public function getEdittable()
    {
        return $this->setEdittable();
    }

    public function updateEdittable($id)
    {
        return $this->doUpdateEdittable($id);
    }


    public function getEdittableById($id)
    {
        $this->id = $id;
        return $this->setEdittableById($this->id);
    }

    public function deletefruit($id)
    {
        return $this->doDeletefruit($id);
    }


    // private function setEdittable()
    // {
    //     $sql = "SELECT * FROM complainant WHERE active = 1 ";
    //     try {
    //         $query = new Query;
    //         return $query->execute($sql);
    //     } catch (\PDOException $e) {
    //         return "Error: " . $e->getMessage();
    //     }
    // }

    private function setEdittableById($id)
    {
        $sql = "SELECT c.*,cc.*  FROM complainant c,complaint_case cc WHERE c.id = '$id' ";
        try {
            $query = new Query;
            return $query->execute($sql);
        } catch (\PDOException $e) {
            return "Error: " . $e->getMessage();
        }
    }

    // private function doUpdateEdittable($id)
    // {
    //     $Edittable = $this->setEdittableData();
    //     $sql = "UPDATE fruit 
    //             SET fruits = '$Edittable[fruits]', ea = '$Edittable[ea]' 
    //             WHERE id = $id";
    //     try {
    //         $query = new Query();
    //         $query->execute($sql);
    //         return "success";
    //     } catch (\PDOException $e) {
    //         return "Error: " . $e->getMessage();
    //     }
    // }

}
