<?php

class Dashboard
{
}
