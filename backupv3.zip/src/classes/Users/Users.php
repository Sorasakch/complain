<?php

/* CRUD DEMO */

/* 

    ให้สร้าง Method เป็นลักษณะของ GET-SET Function หรือ 
    โดยสร้าง Method ที่จะเรียกใช้งานจากภายนอกเป็น Public เป็น Get Function
    และให้สร้าง Method ที่เชื่อมต่อกับฐานข้อมูล Private เป็น Set Function
    
    ตัวอย่าง

    public function getData () 
    {
        return $this->setData;
    }

    private function setData () 
    {
        try {
        $sql = 'SELECT * FROM TABLE';
        $result = $sql->execute($sql);
        return $result;
        } catch (\PDOException $e) {
            return $e->getMessage();
        }
    }

*/

class Users
{
    private function getUserInput()
    {
        return array(
            'firstname' => $_POST['firstnameInput'],
            'lastname' => $_POST['lastnameInput'],
            'password' => $_POST['passwordInput'],
            'email' => $_POST['emailInput'],
            'tel' => $_POST['telInput'],
            'role' => $_POST['roleInput'],
        );
    }

    public function getShowUser()
    {
        return $this->setShowUser();
    }

    private function setShowUser()
    {
        try {
            $query = new Query;
            $sql = "SELECT id, firstname as 'ชื่อจริง', lastname as 'นามสกุล', email as 'email', role as 'บทบาท' 
                FROM users
                WHERE active = 1";
            return $query->execute($sql);
        } catch (\PDOException $e) {
            return $e->getMessage();
        }
    }

    public function addUser()
    {
        $user = $this->getUserInput();
        if ($this->checkDupeUser($user['email']) == true) {
            return "duplicate user";
        } else {
            return $this->doUserAdd();
        }
    }

    private function checkDupeUser($email)
    {
        $query = new Query();
        $sql = "SELECT COUNT(*) as countUser FROM users WHERE email = '{$email}'";
        $result = $query->execute($sql);
        if ($result[0]['countUser'] != 0) {
            return true;
        } else {
            return false;
        }
    }

    private function doUserAdd()
    {
        $user = $this->getUserInput();
        $sql = "INSERT INTO users (firstname, lastname, email, password, tel, role, active) 
            VALUES ('$user[firstname]', '$user[lastname]', '$user[email]', md5('$user[password]'), '$user[tel]', '$user[role]', 1)";
        try {
            $query = new Query();
            $query->execute($sql);
            return "success";
        } catch (\PDOException $e) {
            return $e->getMessage();
        }
    }

    public function getUserById($id)
    {
        return $this->setUserById($id);
    }

    private function setUserById($id)
    {
        try {
            $sql = "SELECT * FROM users WHERE id = $id";
            $query = new Query();
            $this->users = $query->execute($sql);
            return $this->users[0];
        } catch (\PDOException $e) {
            return $e->getMessage();
        }
    }

    public function updateUser($id)
    {
        return $this->doUserUpdate($id);
    }

    private function doUserUpdate($id)
    {
        try {
            $user = $this->getUserInput();
            $sql = "UPDATE users 
                SET firstname = '$user[firstname]', lastname = '$user[lastname]', password =  md5('$user[password]'), email = '$user[email]', tel = '$user[tel]', role = '$user[role]' 
                WHERE id = $id";
            $query = new Query();
            $query->execute($sql);
            return "success";
        } catch (\PDOException $e) {
            return $e->getMessage();
        }
    }

    public function deleteUser($id)
    {
        return $this->doDeleteUser($id);
    }

    private function doDeleteUser($id)
    {
        try {
            $sql = "UPDATE users 
                SET active = 0 
                WHERE id = $id";
            $query = new Query();
            $query->execute($sql);
            return "success";
        } catch (\PDOException $e) {
            return $e;
        }
    }
}
