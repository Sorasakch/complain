<style>
@media(max-width: 320px){ 
    .responsive-img {
        width: 100%;
        height: auto;

    }
}
@media screen and (min-width: 300px) {
    .responsive-img {
        width: 90%;
        height: auto;

    }
}
@media screen and (min-width: 700px) {
    .responsive-img {
        width: 50%;
        height: auto;

    }
}
@media screen and (min-width: 992px) {
    .responsive-img {
        width: 25%;
        height: auto;

    }
    
    
}
</style>

<div class="jumbotron" style="background-color: #eee;">

<img src="/public/images/logo.png" class="responsive-img"/>

    <h1 class=" display-3"><?= SYSNAME; ?></h1>
    <p class="lead"><?= SYSNAME; ?></p>
    <hr class="my-2">
    <p>Created By BICT-MOE 2565
        <script>
            // document.write(new Date().getFullYear() + 543)
        </script>
    </p>
    <p class="lead">
        <a class="btn btn-primary btn-lg" href="/"  role="button">หน้าแรก</a>
    </p>
</div>