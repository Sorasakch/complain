<?php

$tableData = getCustomUsersView();

function tableHeader($header)
{
    foreach ($header[0] as $key => $value) {
        echo '<th>' . $key . '</th>';
    }
    echo '<th>Actions</th>';
}

function tableBody($data)
{
    foreach ($data as $row) {
        echo '<tr>';
        foreach ($row as $key => $value) {
            echo '<td>' . $value . '</td>';
        }
        echo '<td>' . editBtn($row['id']) . delBtn($row['id']) . '</td>';
        echo '</tr>';
    }
}

function editBtn($id)
{
    return '<button class="btn btn-info btn-sm btn-round btn-fab btn-link" onclick="editBtn(' . $id . ')" data-toggle="modal" data-target="#userFormModal"><i class="material-icons">edit</i></button>';
}
function delBtn($id)
{
    return '<button class="btn btn-danger btn-sm btn-round btn-fab btn-link" onclick="delBtn(' . $id . ')"><i class="material-icons">close</i></button>';
}
?>

<div class="material-datatables">
    <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
        <thead>
            <tr><?php tableHeader($tableData); ?></tr>
        </thead>
        <tfoot>
            <tr><?php tableHeader($tableData); ?></tr>
        </tfoot>
        <tbody><?php tableBody($tableData); ?></tbody>
    </table>
</div>


<script>
    $(document).ready(function() {
        $('#datatables').DataTable({
            responsive: true,
        });
    })

    function editBtn(id) {
        userEditModalInit(id)
    }

    function delBtn(id) {
        Swal.fire({
            title: 'ต้องการลบผู้ใช้นี้',
            type: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            confirmButtonText: 'ยืนยัน',
            cancelButtonColor: '#d33',
            cancelButtonText: 'ยกเลิก'
        }).then((result) => {
            if (result.value) {
                axios
                    .delete('userDelete/' + id)
                    .then(res => {
                        if (res.data == 'success') {
                            Swal.fire({
                                type: 'success',
                                title: 'ลบผู้ใช้สำเร็จ',
                                confirmButtonText: 'ตกลง',
                                onClose: () => {
                                    location.reload()
                                }
                            })
                        } else {
                            Swal.fire({
                                type: 'error',
                                title: 'ไม่สามารถลบผู้ใช้นี้ได้',
                                text: 'กรุณาติดต่อผู้ดูแลระบบ',
                                confirmButtonText: 'ตกลง',
                            })
                        }
                    })
                // Swal.fire(
                //     'Deleted!',
                //     'Your file has been deleted.',
                //     'success'
                // )
                // axios
                //     .delete('userDelete/' + id)
                //     .then(res => {
                //         if (res.data == 'success') {
                //             location.reload();
                //         } else {
                //             Swal.fire({
                //                 type: 'error',
                //                 title: 'ไม่สามารถลบผู้ใช้นี้ได้',
                //                 text: 'กรุณาติดต่อผู้ดูแลระบบ'
                //             })
                //         }
                //     })
            }
        })
    }
</script>