<!DOCTYPE html>
<style>
    #search_btn {
        background-color: #ec407a;
        color: #fff;
    }

    #show_div {

        width: 100%;
        padding: 50px 0;
        text-align: center;
        margin-top: 20px;
    }
</style>


<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-rose">
                <h4 class="card-title">
                    <img src="/public/images/mag.png" alt="" width="3%">
                    ค้นหาด้วยเบอร์โทรศัพท์หรืออีเมล
                </h4>
            </div>
            <div class="card-body">
                <form id="search_form" align="center">
                    <div class="form-group" align="center">
                        <input type="text" name="searchtoken" id="searchtoken" placeholder="กรอกเบอร์โทรศัพท์หรืออีเมล" style="width:100%;text-align:center;height:50px;font-size:large;">
                    </div>
                    <div align="center">
                    <button class="btn btn-success btn-lg"><i class="fa fa-search"></i> ค้นหา</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>



<div id="show_div" class="row d-none">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-rose">
                <h3 class="card-title">ผลการค้นหา</h3>
            </div>

            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                                
                       <div id="div1">
                       <p id="demo"></p>
                        </div>
     


                            <div id="div2">
                 
                            
                            <p>ท่านกรอกรหัสติดตามผิดหรือไม่พบเรื่องร้องเรียนของท่าน</p>

            
           
                            </div>


                
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function searchTicketId() {
        $('#show_div').removeClass('d-none');
    }

    
    $("search_form").ready(() => {

        onSubmit()
     
    })

    function onSubmit() {
        $("#search_form").submit(function(e) {
            e.preventDefault()
            var formData = new FormData(this);
            axios
                .post('checktoken/checktokensearch', formData)
                .then((res) => {
  
                    // swal.fire({
                    //         type: "success",
                    //         title: "สำเร็จ<br/>",
                    //         text: "บันทึกข้อมูลเรียบร้อยแล้ว"
                    //     })
                    //     .then(function() {
                            if(res.data == "0")
                            {
                                searchTicketId();
                                document.getElementById('div1').style.display = 'none';
                                document.getElementById('div2').style.display = 'block';
                                                
                            }
                            else{
                                searchTicketId();
                                appendData(res.data);
                    
                            }
     
                             
                        // })
                })
        })
    }


    function appendData(data) {
        // data = JSON.stringify(data)
        // data.forEach((item, index) => {
        document.getElementById('div1').style.display = 'block';
        document.getElementById('div2').style.display = 'none';
        // const cars = item.token;
        //  console.table(data[1].token);


        let text = "";
        for (let i = 0; i < data.length; i++) {
        text += data[i].token + " <br>";
        // text2 += data[i].complaint_date + "<br>";
        }
        


        document.getElementById("demo").innerHTML = text;
        // document.getElementById("demo2").innerHTML = text2;

        // })
    }




</script>