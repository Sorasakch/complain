
<script>


var track = localStorage.getItem('com_token');

if(track == null)
{
    window.location.href = "/";

}
else
{
}



</script>

<style>

.track {
  font-size: 18px;
  color: red;

}
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>รหัสติดตามเรื่องร้องเรียน</title>
</head>
<body>
<div class="card">
   
    <div class="card-body">
    <center><img src="/public/images/success.png"></center>

    <div class="row">
    <center>
    <h3>รหัสติดตามเรื่องร้องเรียน</h3>
     <p class="track" style="font-size: 24px;" id="track"> </p> 
     <p>กรุณาเก็บรหัสติดตามเรื่องร้องเรียนไว้เป็นความลับ เพื่อใช้ติดตามการร้องเรียนของท่าน</p>
     <p>หากท่านลืมรหัสติดตามสามารถตรวจสอบได้โดย <a href="/public/checktoken">คลิกที่นี่</a></p>
    </center>

    </div>
    <div class="card-footer">
            <div class="col-md-12 text-center">
                <button class="btn btn-success btn-lg" onClick="Click()">ตกลง</button>
            </div>
        </div>
</div>
</div>
</body>
</html>

<script>



    document.getElementById('track').innerText = track;
    


        const span =  document.getElementById('track');

        span.onclick = function() {
        document.execCommand("copy");
        }

        span.addEventListener("copy", function(event) {
        event.preventDefault();
        if (event.clipboardData) {
            event.clipboardData.setData("text/plain", span.textContent);
            console.log(event.clipboardData.getData("text"))
            alert("คัดลอกรหัสติดตามแล้ว")
        }
        });


        function Click() {
            localStorage.clear();

        window.location.href="/";
      }

</script>