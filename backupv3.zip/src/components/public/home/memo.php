<style>

<?php
$getData = getmemo();
?>

</style>



<div class="memo">ประกาศ</div>
<div class="card card-stats">
    <div class="card-header card-header-rose card-header-icon">
           <marquee style="cursor:pointer;margin:10px;  color: <?php print_r($getData[0]['color']);?>"
            class="notice" onmouseover="this.stop()" onmouseout="this.start()" 
            scrollamount="8">
            <?php
              print_r($getData[0]['announcement']);
              ?>
          
            </marquee>
                  </div>
                </div>

            