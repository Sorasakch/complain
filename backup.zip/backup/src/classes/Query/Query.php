<?php

/* 

!!EDIT WITH YOUR OWN RISK!! 

class Query ส่วนขยายของ class Connection

__construct() เปิดการเชื่อมต่อฐานข้อมูลเมื่อมีการเรียกใช้คลาส
execute($sql) ทำการส่งคำสั่ง SQL ไปยังฐานข้อมูล และ return ข้อมูลออกมาเป็นอาเรย์

วิธีใช้
$sql = 'SELECT * FROM TABLE';
$query = new Query();
$result = $query->execute($sql);
var_dump($result);

*/

class Query extends Connection
{

    private static $conn;

    public function __construct()
    {
        self::$conn = new Connection;
        $this->openconn = self::$conn->openConnection();
    }

    public function execute($sql)
    {
        $this->stmt = $this->openconn->prepare($sql);
        $this->stmt->execute();
        $this->arr = array();
        while ($row = $this->stmt->fetchAll(PDO::FETCH_ASSOC)) {
            $this->arr = $row;
        }
        self::$conn->closeConnection();
        return $this->arr;
    }
}
