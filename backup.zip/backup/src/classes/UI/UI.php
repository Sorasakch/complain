<?php

class UI
{
    public function dataTable($header = [], $data = [], $editRoute = "", $deleteRoute = "")
    {
        echo '<div class="material-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
        <thead>
            <tr>';
        foreach ($header as $key => $value) {
            echo '<th>' . $value . '</th>';
        }
        echo '<th class="text-center">actions</th>
        </tr>
        </thead>
        <tfoot>
            <tr>';
        foreach ($header as $key => $value) {
            echo '<th>' . $value . '</th>';
        }

        echo '<th class="text-center">actions</th>
        </tr>
        </tfoot>
        <tbody>';
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $key => $value) {
                echo '<td>' . $value . '</td>';
            }
            echo '
                <td class="text-center">
                <button class="btn btn-info btn-sm btn-round btn-fab btn-link" onclick="editBtn(\'' . $editRoute . '\',\'' . $row["id"] . '\')"><i class="material-icons">edit</i></button>
                <button class="btn btn-danger btn-sm btn-round btn-fab btn-link" onclick="delBtn(\'' . $deleteRoute . '\',\'' . $row["id"] . '\')"><i class="material-icons">close</i></button>
                </td></tr>';
        }
        echo '</tbody>
        </table>
        <script src="js/dataTable.js"></script>
        ';
    }

public function dataTable2($header = [], $data = [], $editRoute = "", $deleteRoute = "")
    {
        echo '<div class="material-datatables">
        <table id="datatables" class="table table-striped table-no-bordered table-hover" cellspacing="0" width="100%" style="width:100%">
        <thead>
            <tr>';
        foreach ($header as $key => $value) {
            echo '<th>' . $value . '</th>';
        }
        echo '<th class="text-center">actions</th>
        </tr>
        </thead>
        <tfoot>
            <tr>';
        foreach ($header as $key => $value) {
            echo '<th>' . $value . '</th>';
        }

        echo '<th class="text-center">actions</th>
        </tr>
        </tfoot>
        <tbody>';
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $key => $value) {
                if($key == "status"){
                    if ($value == 0) {
                            echo '<td><span class="badge badge-secondary">รอดำเนินการ</span></td>';
                        }
                         else if ($value == 1) {
                            echo '<td><span class="badge badge-warning">กำลังดำเนินการ</span></td>';
                        } else if ($value == 2){
                            echo '<td><span class="badge badge-success">เสร็จสิ้น</span></td>';
                        }
                        else{
                                echo '<td>' . $value . '</td>';
                            }   
                }
                else{
                    echo '<td>' . $value . '</td>';

                }
          
            }
            if($value == 2){
                echo '
                <td class="text-center">
                <button class="btn btn-info btn-sm btn-round btn-fab btn-link" onclick="getId('. $row["id"] . ')" data-toggle="modal" data-target="#complainFormModal"><i class="fa fa-eye"></i></button>
                </td></tr>';
            }
            //<button class="btn btn-info btn-sm btn-round btn-fab btn-link" onclick="editBtn(\'' . $editRoute . '\',\'' . $row["id"] . '\')"><i class="fa fa-eye"></i></button>

            // <button class="btn btn-info btn-sm btn-round btn-fab btn-link" data-toggle="modal" data-target="#userFormModal"><i class="fa fa-eye"></i></button>

            else{
                echo '
                <td class="text-center">
                <button class="btn btn-info btn-sm btn-round btn-fab btn-link"  onclick="getId('. $row["id"] . ')" data-toggle="modal" data-target="#complainFormModal"><i class="material-icons">edit</i></button>                <button class="btn btn-danger btn-sm btn-round btn-fab btn-link" onclick="delBtn(\'' . $deleteRoute . '\',\'' . $row["id"] . '\')"><i class="material-icons">close</i></button>
                </td></tr>';
            }
        }
        echo '</tbody>
        </table>
        <script src="js/dataTable.js"></script>
        ';
    }


    public function simpleTable($header = [], $data = [])
    {
        echo '
        <div class="table-responsive">
            <table class="table">
                <thead>
        ';
        echo
        '
        <tr>';
        foreach ($header as $key => $value) {
            echo '<th>' . $value . '</th>';
        }
        echo '</tr>
        ';
        echo
        '
        <tbody>';
        foreach ($data as $row) {
            echo '<tr>';
            foreach ($row as $key => $value) {
                echo '<td>' . $value . '</td>';
            }
            echo '</tr>';
        }
        echo '</tbody>
        </table>
        </div>
        ';
    }

    public function selectPicker($id, $arr = [], $defaultValue = "", $config = array("data-size" => "3", "data-style" => "btn btn-rose btn-sm", "title" => "กรุณาเลือกข้อมูล", "required" => "false"))
    {
        echo '<div class="form-group">
        <select 
        class="selectpicker" 
        id="roleSelect" 
        name="roleInput" 
        data-size="' . $config['data-size'] . '" 
        data-style="' . $config['data-style'] . '" 
        title="' . $config['title'] . '" ';
        echo ($config['required'] == "true") ? 'required="true"' : '';
        echo '>';
        foreach ($arr as $key => $value) {
            if ($defaultValue == $value['value']) {
                echo '<option value="' . $value['value'] . '" selected>' . $value['title'] . '</option>';
            } else {
                echo '<option value="' . $value['value'] . '">' . $value['title'] . '</option>';
            }
        }
        echo '</select></div>';
    }





}
