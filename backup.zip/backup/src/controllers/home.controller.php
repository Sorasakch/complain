<?php

function pageTitle() {
    return 'HOME';
}

?>