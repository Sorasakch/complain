<?php

function getCompliantCase()
{
    $compliant = new Complaint;
    return $compliant->getComplaintCase();
}

function makeComplaint()
{

    $complaint = new Complaint;
    return $complaint->makeComplaint();


    // try {
    //     $complaint = new Complaint;
    //     print_r(json_encode($complaint->makeComplaint()));
    // } catch (Exception $e) {
    //     return json_encode($e->getmessage());
    // }
}
