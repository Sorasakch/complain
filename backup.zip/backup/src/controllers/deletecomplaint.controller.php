<?php

function pageTitle()
{
    return 'ผู้ใช้งาน';
}




function deletecomplaint($id)
{
    $sql = "UPDATE 
    complaint_case,complainant SET complaint_case.status = 9
    , complainant.status = 9 
    WHERE complaint_case.id = $id & complainant.id = $id ";


    try {
        $query = new Query();
        $query->execute($sql);

        return "success";
    } catch (\PDOException $e) {
        return "Error: " . $e->getMessage();
    }
}