<!DOCTYPE html>
<html lang="en">

<head>
    <!-- เรียกใช้งาน Script -->
    <?php require_once "src/views/layout/headerScript.php"; ?>
    <!-- ชื่อระบบ -->
    <title><?= SYSNAME; ?></title>
</head>

<body>
    <div class="wrapper">
        <!-- เรียกใช้งาน sidebar -->
        <?php require_once "src/views/layout/sidebar.php"; ?>
        <div class="main-panel">
            <!-- เรียกใช้งาน headNav -->
            <?php require_once "src/views/layout/headNav.php"; ?>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            <!-- เรียกใช้งาน Component -->
                            <?php
                            include "src/components/complaint/complianTable.php";
                            include "src/components/complaint/modal.php"; //popup
                            ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- เรียกใช้งาน footer -->
            <?php include "src/views/layout/footer.php"; ?>
        </div>
    </div>
    <!-- เรียกใช้งาน Script -->
    <?php require_once "src/views/layout/footerScript.php"; ?>
</body>

</html>