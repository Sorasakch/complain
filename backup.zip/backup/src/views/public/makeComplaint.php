<!DOCTYPE html>
<html lang="en">

<head>
    <?php require_once "src/views/layout/headerScript.php"; ?>
    <title><?php  ?></title>
</head>

<body>
    <div class="wrapper">
        <?php require_once "src/views/layout/publicHeadNav.php"; ?>
        <div class="content">
            <div class="container">
                <div class="toolbox">
                    <div class="row">
                        <div class="col-md-6 text-start">
                            <h3 class="d-inline align-middle">แจ้งเรื่องร้องเรียน</h3>
                        </div>
                        <div class="col-md-6 text-end">
                            <span class="d-inline align-middle">home / complaint</span>
                        </div>
                    </div>
                </div>
                <div class=" row">
                    <div class="col-md-12">
                        <?php include "src/components/public/makeComplaint/complaintForm.php"; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php include "src/views/layout/footer.php"; ?>
    </div>
    <?php require_once "src/views/layout/footerScript.php"; ?>
</body>

</html>