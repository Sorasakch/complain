<!--   Core JS Files   -->
<script src="<?php echo ROOT . '/assets/js/plugins/perfect-scrollbar.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/sweetalert2.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/jquery.validate.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/jquery.bootstrap-wizard.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/bootstrap-tagsinput.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/jasny-bootstrap.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/fullcalendar.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/jquery-jvectormap.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/nouislider.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/arrive.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/chartist.min.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/plugins/bootstrap-notify.js'; ?>"></script>
<script src="<?php echo ROOT . '/assets/js/material-dashboard.js?v=2.2.2'; ?>" type="text/javascript"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/core-js/2.4.1/core.js"></script>
<script src="<?php echo ROOT . '/js/axios.min.js'; ?>"></script>