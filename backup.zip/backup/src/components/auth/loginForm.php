<form class="form" id="loginForm">
    <div class="card card-login">
        <div class="card-header text-center <?php echo loginPageconf()['cardHeaderColor']; ?>">
            <div class="photo">
                <img src="<?php echo loginPageconf()['cardHeaderImg']; ?>" alt="" width="20%">
            </div>
            <h4 class="card-title"><?php echo loginPageconf()['cardHeaderTitle']; ?></h4>
        </div>
        <div class="card-body ">
            <span class="bmd-form-group">
                <div class="input-group">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="material-icons">email</i>
                        </span>
                    </div>
                    <input type="email" id="emailInput" name="emailInput" class="form-control" placeholder="Email...">
                </div>
            </span>
            <span class="bmd-form-group">
                <div class="input-group mt-3">
                    <div class="input-group-prepend">
                        <span class="input-group-text">
                            <i class="material-icons">lock</i>
                        </span>
                    </div>
                    <input type="password" id="passwordInput" name="passwordInput" class="form-control" placeholder="Password...">
                </div>
            </span>
        </div>
        <div class="card-footer justify-content-center mt-3">
            <div class="row">
                <div class="col-md-12">
                    <button class="btn <?php echo loginPageconf()['btnColor']; ?> mb-3 text-center" type="submit" id="submitBtn">
                        <div style="min-width:100px; max-height:15px;"><span id="loginBtnTitle"><?php echo loginPageconf()['loginBtnTitle']; ?></span></div>
                        <div style="min-width:100px; max-height:15px;"><span id="loginBtnSpinner" class="spinner-border spinner-border-sm d-none" role="status"></span></div>
                    </button>
                </div>
            </div>

        </div>
    </div>
</form>
<script>
    /* ELEMENT BINDING ประกาศตัวแปรผูกกับ element */
    let loginForm = document.getElementById('loginForm');
    let submitBtn = document.getElementById('submitBtn');
    let loginBtnTitle = document.getElementById('loginBtnTitle');
    let loginBtnSpinner = document.getElementById('loginBtnSpinner');

    $(document).ready(() => { // เริ่มทำงานเมื่อโหลดหน้าเพจเสร็จสิ้น
        submitListener(); // เรียกใช้งานฟังก์ชั่นการส่งข้อมูล
    })

    function submitListener() { // ฟังก์ชั่นการส่งข้อมูล
        loginForm.addEventListener('submit', () => { // เมื่อมีการกดปุ่มส่งข้อมูล
            event.preventDefault(); // ปิดการทำงานปกติ
            submitBtn.disabled = true; // Disable ปุ่ม
            loginBtnTitle.classList.add('d-none') // ซ่อนปุ่ม
            loginBtnSpinner.classList.remove('d-none') // แสดง Spinner
            let formData = new FormData(loginForm); // สร้างตัวแปรสำหรับรับข้อมูลจาก form
            axios // เรียกใช้ axios
                .post('login', formData) // ส่งข้อมูลไปยังหน้า login แบบ POST โดยส่งข้อมูลเป็น formData
                .then((res) => { // ส่งข้อมูลเสร็จสิ้น เก็บค่าที่ได้กลับมาไว้ในตัวแปร res
                    setTimeout(() => { // ตั้งเวลาให้การแสดงผลทำงาน
                        if (res.data === 1) { // ถ้ามีข้อมูลกลับมา
                            window.location.href = './home'; // ไปยังหน้าเพจหลัก
                        } else { // ถ้าไม่มีข้อมูลกลับมา
                            swal.fire({ // แสดงข้อความแจ้งเตือน
                                type: 'error',
                                title: 'อีเมล์หรือรหัสผ่านไม่ถูกต้อง',
                                text: 'กรุณาตรวจสอบข้อมูลอีกครั้ง',
                                confirmButtonText: 'ตกลง',
                                onClose: resetButton()
                            });
                        }
                    }, 500); // หน่วงเวลาที่จะแสดงผลการทำงาน 500ms
                })
                .catch((error) => { // กรณีที่เกิดข้อผิดพลาด
                    console.log(error.response)
                    swal.fire({ // แสดงข้อความแจ้งเตือน
                        type: 'error',
                        title: 'เกิดข้อผิดพลาด',
                        text: 'กรุณาตรวจสอบข้อมูลอีกครั้ง',
                        confirmButtonText: 'ตกลง',
                        onClose: resetButton()
                    });
                })
        })
    }

    function resetButton() { // ฟังก์ชั่นการรีเซตปุ่ม
        submitBtn.disabled = false // Enable ปุ่ม
        document.getElementById('emailInput').focus(); // Focus ที่ช่องอีเมล์
        loginBtnSpinner.classList.add('d-none') // ซ่อน Spinner
        loginBtnTitle.classList.remove('d-none') // แสดงปุ่ม
    }
</script>