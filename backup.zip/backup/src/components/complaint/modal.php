<style>
    #roleSelect-error {
        margin-left: 10px;
    }

    .filter-option {
        color: #ffffff;
        font-size: 1.1em;
    }
</style>

<div class="modal fade" id="complainFormModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title" id="modalTitle">รายละเอียดการร้องเรียน</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                
                <div class="row">
                    <form id="complaintForm" class="form-horizontal">
                        <div class="card mt-5">
                            <div class="card-header card-header-rose">
                                <h4 class="card-title">
                                    ข้อมูลผู้ร้องเรียน
                                </h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                <label style="text-align: right; color: #e73673;">เลขที่ร้องเรียน : <label style="text-align: right; color: #000;" id="id_com"></label> </label>
                                    <label style="text-align: right; color: #e73673;">รหัสติดตาม : <label style="text-align: right; color: #000;" id="id_track"></label></label>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label text-center">ชื่อผู้แจ้ง</label>
                                    <div class="col-sm-10">
                                        <div class="form-group">
                                            <input type="text" id="complainantName" name="complainantName" class="form-control" placeholder="ชื่อ นามสกุล" value="" readonly />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label text-center">อีเมล์</label>
                                    <div class="col-sm-10">
                                        <div class="form-group">
                                            <input type="text" id="emailInput" name="emailInput" class="form-control" placeholder="e-mail" email="true" value="" readonly />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label text-center">เบอร์ที่ติดต่อได้</label>
                                    <div class="col-sm-10">
                                        <div class="form-group">
                                            <input type="text" id="telInput" name="telInput" class="form-control" value="" readonly />
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <label class="col-sm-2 col-form-label text-center">ประเภทของผู้ร้องเรียน</label>
                                    <div class="col-sm-10">
                                        <div class="form-group">
                                            <input type="text" id="complainantTypeInput" name="complainantTypeInput" class="form-control" value="" readonly />
                                        </div>
                                    </div>
                
                                    <div class="card mt-5">
                                        <div class="card-header card-header-rose">
                                            <h4 class="card-title">
                                                รายละเอียดการแจ้งเบาะแสการทุจริต และ คุณธรรม จริยธรรม
                                            </h4>
                                        </div>
                                        <div class="card-body">

                                            <div class="row">
                                                <label class="col-sm-2 col-form-label text-center">ประเภทเรื่องร้องเรียน</label>
                                                <div class="col-sm-10">
                                                    <div class="form-group">
                                                        <input type="text" id="complainanttopic" name="complainanttopic" class="form-control" value="" readonly />
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row">
                                                <label class="col-sm-2 col-form-label text-center">หัวข้อเรื่อง</label>
                                                <div class="col-sm-10">
                                                    <div class="form-group">
                                                        <input type="text" id="complaintCaseTitleInput" name="complaintCaseTitleInput" class="form-control" placeholder="" value="" readonly />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <label class="col-sm-2 col-form-label text-center" required="true">รายละเอียดเรื่องร้องเรียน</label>
                                                <div class="col-sm-10">
                                                    <div class="form-group">
                                                        <textarea id="complaintDetailInput" name="complaintDetailInput" class="form-control" rows=" 3" readonly /></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <label class="col-sm-2 col-form-label text-center" required="true">บุคคล/หน่วยงานที่ต้องการร้องเรียน</label>
                                                <div class="col-sm-10">
                                                    <div class="form-group">
                                                        <input type="text" id="defenderInput" name="defenderInput" class="form-control" placeholder="ชื่อบุคคล / หน่วยงาน" value="" readonly />
                                                    </div>
                                                </div>
                                            </div>


                                            <div class="row">
                                                <label class="col-sm-2 col-form-label text-center" required="true"></label>
                                                <div class="col-sm-10">
                                                <div class="form-check">
                                                    <label class="form-check-label" id="ra2">
                                                    <input class="form-check-input" type="radio" id="statusInput" name="statusInput" value="1" checked>รับเรื่องร้องเรียน
                                                        <span class="circle">
                                                        <span class="check"></span>
                                                        </span>
                                                    </label>
                                                    </div>
                                                    
                                                    <div class="form-check">
                                                    <label class="form-check-label" id="ra">
                                                        <input class="form-check-input" type="radio" id="statusInput" name="statusInput" value="2">ดำเนินการเสร็จสิ้นแล้ว
                                                        <span class="circle">
                                                        <span class="check"></span>
                        
                                                        </span>
                                                    </label>
                                                    <label style="text-align: right; color: #e73673;" id="ra3">* หากเลือกดำเนินการเสร็จสิ้นจะไม่สามารถกลับมาแก้ไขได้*</label>
                                                    <h4 class="card-title" id="suc" style=" text-align: center;">
                                                    ดำเนินการเสร็จสิ้น
                                                    </h4>
                                                    </div>
                                                </div>
                                            </div>

    
                                        </div>
                                        <div class="card-footer">
                                            <div class="col-md-12 text-center" id="bt-send">
                                                <button class="btn btn-success btn-lg">บันทึก</button>
                                            </div>
                                     
                                        </div>
                                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<script>





    function getId(id) {
        getComplainDetail(id)



        $('#complaintForm').submit(function(e) {
        e.preventDefault();
        if ($(this).valid()) {
            var formData = new FormData($(this)[0]);
            if (id) {
                axios
                    .post('complaint/complianUpdate/' + id, formData)
                    .then(res => {
                        console.log(res.data);
                        if (res.data == "success") {
                            Swal.fire({
                                title: "สำเร็จ",
                                text: "บันทึกข้อมูลเรียบร้อย",
                                type: "success",
                                confirmButtonClass: "btn btn-success",
                                confirmButtonText: "ตกลง",
                            }).then(() => {
                                window.location.href = "complaint";
                            });
                        } else {
                            Swal.fire({
                                title: "ผิดพลาด",
                                text: "บันทึกข้อมูลไม่สำเร็จ",
                                type: "error",
                                confirmButtonClass: "btn btn-danger",
                                confirmButtonText: "ตกลง",
                            });
                        }
                    })

            }
        }
    });




        
    }

    function getComplainDetail(id) {
        axios
            .get(`complaint/editcomplian/${id}`)
            .then((res) => {
                // console.log(res.data)
                appendData(res.data)
            })

    
        }

    function appendData(data) {
        console.log(data)
        $("#id_com").empty().text(data.id)
        $("#id_track").empty().text(data.token)
        $("#complainantName").empty().val(data.fullname)
        $("#emailInput").empty().val(data.email)
        $("#telInput").empty().val(data.tel)
        $("#complainantTypeInput").empty().val(data.responder)

        $("#complainanttopic").empty().val(data.type)
        $("#complaintCaseTitleInput").empty().val(data.title)
        $("#complaintDetailInput").empty().val(data.detail)
        $("#defenderInput").empty().val(data.defender)


             var x = document.getElementById("bt-send");
             var y = document.getElementById("ra");
             var z = document.getElementById("ra2");
             var a = document.getElementById("ra3");
             var b = document.getElementById("suc");

            if (data.status == 2) {
                x.style.display = "none";
                y.style.display = "none";
                z.style.display = "none";
                a.style.display = "none";
                b.style.display = "block";

                
            } else {
                x.style.display = "block";
                y.style.display = "block";
                z.style.display = "block";
                a.style.display = "block";
                b.style.display = "none";
            }
    }
</script>