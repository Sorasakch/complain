<style>
.notice{

color: red;
}

</style>
<div class="memo">ประกาศ</div>
<div class="card card-stats">
    <div class="card-header card-header-rose card-header-icon">
           <marquee style="cursor:pointer;margin:10px;" 
            class="notice" onmouseover="this.stop()" onmouseout="this.start()" 
            scrollamount="8">
            ต้องการแจ้งเรื่อง แจ้งเบาะแส ตลอดจนข้อคิดเห็นข้อเสนอแนะ กรุณาคลิ๊กที่แจ้งเรื่องร้องเรียน 
            หรือติดต่อศูนย์บริการร่วม กระทรวงศึกษาธิการ!!
            </marquee>
                  </div>
                </div>