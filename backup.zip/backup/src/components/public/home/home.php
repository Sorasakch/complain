<?php include "src/components/public/home/memo.php"; ?>

<div class="col-md-5" style="margin: auto;
                width: 100%;
                padding: 10px;">
    <div>
        <img src="/public/images/memo.jpg" alt="" class="responsive-img" width="100%" height="auto">
        <div class="card card-chart">
            <div class="card-body">
                <h4 class="card-title">
                    ช่องทางที่ท่านสามารถแจ้งเรื่องร้องเรียนต่อกระทรวงศึกษาธิการ มีดังนี้
                </h4>
                <hr class="new1" style="  border-top: 1px solid black;">
                <p class="card-category">1.เว็บไซต์ http://site-test6.wisstech.info/public/home</p>
                <p class="card-category">2.จดหมายอิเล็กทรอนิกส์ (E-Mail) : test@moe.go.th</p>
                <p class="card-category">3.ส่งหนังสือร้องเรียนมาที่กระทรวงศึกษาธิการ 319 ถนน ราชดำเนินนอก แขวง ดุสิต เขตดุสิต กรุงเทพมหานคร 10300</p>
                <p class="card-category">4.มายื่นหนังสือร้องเรียนด้วยตนเองที่ กระทรวงศึกษาธิการ</p>
                <p class="card-category">5.สายด่วน Education Call 1579 หรือ 02-280-0306</p>
                <p class="card-category">6.โทรสาร (Fax) : 0-2849-7102</p>
            </div>
        </div>
    </div>
</div>
<!-- -------------------------------------------------------------------- -->

<div class="container-fluid" style="background-color:#e91e63;">
    <div class="container">
        <div class="row">
            <div class=" col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <a href="/public/makeComplaint">
                    <div class="col-lg-12 col-md-12 col-sm-12 border_com-index" style="width:100%;">
                        <div id="photo" style="text-align: center; vertical-align:middle;">
                            <img src="/public/images/megaphone.png" alt="">
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12">

                            <div class="headtypecom-index">แจ้งเรื่องร้องเรียน/เสนอความคิดเห็น</div>
                            <div class="txttypetxt-index">หรืออาจแจ้งข้อมูลเพิ่มเติม</div>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                <a href="/public/trackComplaint">
                    <div class="col-lg-12 col-md-12 col-sm-12 border_com-index" style="width:100%;">
                        <div id="photo" style="text-align: center; vertical-align:middle;">
                            <img src="/public/images/notic.png" alt="">
                        </div>
                        <div class="col-lg-9 col-md-9 col-sm-12">
                            <div class="headtypecom-index">ติดตามเรื่องร้องเรียน</div>
                            <div class="txttypetxt-index">ติดตามความก้าวหน้าของเรื่องที่ร้องเรียนไปแล้ว โดย Ticket ID</div>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- -------------------------------------------------------------------- -->
