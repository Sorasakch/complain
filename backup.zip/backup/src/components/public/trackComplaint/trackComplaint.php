<!DOCTYPE html>
<style>
    #search_btn {
        background-color: #ec407a;
        color: #fff;
    }

    #show_div {

        width: 100%;
        padding: 50px 0;
        text-align: center;
        margin-top: 20px;
    }
</style>

<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-rose">
                <h4 class="card-title">
                    <img src="/public/images/notic.png" alt="" width="3%">
                    ติดตามเรื่องร้องเรียน
                </h4>
            </div>
            <div class="card-body">
                <form id="search_form" align="center">
                    <div class="form-group" align="center">
                        <input type="text" placeholder="กรอก TOKEN สำหรับค้นหา" style="width:900px;text-align:center;height:70px;font-size:xx-large;">
                    </div>
                    <div align="center">
                        <a class="btn btn-primary" id="search_btn" onclick="searchTicketId();" role="button"><i class="fa fa-search"></i> ค้นหา</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<div id="show_div" class="row d-none">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header card-header-rose">
                <h3 class="card-title">สถานะเรื่องร้องเรียน</h3>
            </div>
            <div class="card-body">
                <div class="row justify-content-center">
                    <div class="col-md-6">
                        <ul class="timeline timeline-simple">
                            <li class="timeline-inverted">
                                <div class="timeline-badge danger">
                                    <i class="material-icons">card_travel</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-danger">รับเรื่องร้องเรียน</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>ระบบได้ทำการรับเรื่องร้องเรียนของท่านแล้ว</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> วันที่ 28 สิงหาคม พ.ศ. 2565 เวลา 09:45 น.
                                    </h6>
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge success">
                                    <i class="material-icons">extension</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-success">กำลังดำเนินการ</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>เรื่องร้องเรียนของท่านอยู่ระหว่างดำเนินการ</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> วันที่ 31 สิงหาคม พ.ศ. 2565 เวลา 13:09 น.
                                    </h6>
                                </div>
                            </li>
                            <li class="timeline-inverted">
                                <div class="timeline-badge info">
                                    <i class="material-icons">fingerprint</i>
                                </div>
                                <div class="timeline-panel">
                                    <div class="timeline-heading">
                                        <span class="badge badge-pill badge-info">เรียบร้อย</span>
                                    </div>
                                    <div class="timeline-body">
                                        <p>เรื่องร้องเรียนของท่านได้รับการดำเนินการแล้ว</p>
                                    </div>
                                    <h6>
                                        <i class="ti-time"></i> วันที่ 31 สิงหาคม พ.ศ. 2565 เวลา 16:09 น.
                                    </h6>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function searchTicketId() {
        $('#show_div').removeClass('d-none');
    }
</script>