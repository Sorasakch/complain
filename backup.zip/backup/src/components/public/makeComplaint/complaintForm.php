<style>
    .togglebutton label input[type=checkbox]:checked+.toggle {
        background-color: #e91e63;
    }
</style>
<form id="complaintForm" class="form-horizontal">
    <div class="card mt-5">
        <div class="card-header card-header-rose">
            <h4 class="card-title">
                ข้อมูลผู้ร้องเรียน
            </h4>
        </div>
        <div class="card-body">
            <div class="toolbox">
                <span style="color:red;">หมายเหตุ : ขอความกรุณาให้ท่านกรอกข้อมูลให้ครบทุกช่อง</span>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">ชื่อผู้แจ้ง*</label>
                
                <div class="col-sm-10">
                <div class="form-group">
                 <div class="dropdown bootstrap-select show-tick">

                        <div class="form-check">
                          <label class="form-check-label">
                          <input class="form-check-input" type="radio" id="hidden_s" name="one" value="ปกปิดตัวตน" checked>ปกปิดตัวตน
                            <span class="circle">
                              <span class="check"></span>
                            </span>
                          </label>
                        </div>
                        <div class="form-check">
                          <label class="form-check-label">
                            <input class="form-check-input" type="radio" id="visible_s" name="one" value="เปิดเผยตัวตน">เปิดเผยตัวตน
                            <span class="circle">
                              <span class="check"></span>
                            </span>
                          </label>
                        </div>




                <div class="otherprof" style="display:none;" >
                    <input type="textbox" name="complainantName" id="complainantName" class="form-control"  placeholder="กรอกชื่อนามสกุล" required="true"/ value="ผู้ร้องเรียนประสงค์ปกปิดตัวตน"  >
                </div>
                </div>
            </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">อีเมล์ *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="emailInput" name="emailInput" class="form-control" placeholder="e-mail" required="true" email="true" >
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">เบอร์ที่ติดต่อได้ *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="telInput" name="telInput" class="form-control" placeholder="เบอร์โทรศัพท์" required="true" number="true">
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">ประเภทของผู้ร้องเรียน *</label>
                <div class="col-sm-10">
                    <div class="form-group">

                    <div class="dropdown bootstrap-select show-tick">
                        <select id="complainantTypeInput" name="complainantTypeInput" class="selectpicker" data-style="select-with-transition"  title="เลือกประเภทของผู้ร้องเรียน" data-size="5" tabindex="-98">
                            <option disabled="">เลือกประเภทของท่าน</option>
                            <option value="ประชาชน/ผู้ปกครอง" selected="selected">ประชาชน/ผู้ปกครอง</option>
                            <option value="ข้าราชการ">ครู/ข้าราชการ</option>
                            <option value="นักเรียน/นักศึกษา/เยาวชน">นักเรียน/นักศึกษา/เยาวชน</option>
                        </select>
                    </div>
                </div>
            </div>
            <!-- <div class="row">
                <label class="col-sm-2 col-form-label text-center">ต้องการปกปิดข้อมูลผู้ร้องเรียน</label>
                <div class="col-sm-10 togglebutton">
                    <label class="pt-3" id="dataLabel">
                        <input type="checkbox" id="dataSwitch">
                        <span class="toggle"></span>
                        <span id="switchText">ไม่ปกปิด</span>
                    </label>
                </div>
            </div>
        </div>
    </div> -->
    <div class="card mt-5">
        <div class="card-header card-header-rose">
            <h4 class="card-title">
                เรื่องร้องเรียน
            </h4>
        </div>
        <div class="card-body">
            <div class="row">
                <label class="col-sm-2 col-form-label text-center">ประเภทเรื่องร้องเรียน *</label>
                <div class="col-sm-10">
                <div class="dropdown bootstrap-select show-tick">
                        <select id="complainanttopic" name="complainanttopic" class="selectpicker" data-style="select-with-transition"  title="เลือกประเภทของผู้ร้องเรียน" data-size="5" tabindex="-98">
                                            <option value="" disabled="">---------เลือกประเภท ---------
                                            </option>
                                            <option value="ด้านการทุจริตและประพฤติมิชอบ" selected="selected">
                                                ด้านการทุจริตและประพฤติมิชอบ
                                            </option>
                                            <option value="ด้านคุณธรรม จริยธรรม">
                                            ด้านคุณธรรม จริยธรรม
                                            </option>
                            </select>                
                    </div>
                </div>
            </div>

            <div class="row">
                <label class="col-sm-2 col-form-label text-center">หัวข้อเรื่อง *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="complaintCaseTitleInput" name="complaintCaseTitleInput" class="form-control" placeholder=""  required="true">
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center"  required="true">รายละเอียดเรื่องร้องเรียน *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <textarea id="complaintDetailInput" name="complaintDetailInput" class="form-control" rows=" 3" placeholder="กรุณาระบุโดยละเอียด"></textarea>
                    </div>
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2 col-form-label text-center"  required="true">บุคคล/หน่วยงานที่ต้องการร้องเรียน *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <input type="text" id="defenderInput" name="defenderInput" class="form-control" placeholder="ชื่อบุคคล / หน่วยงาน">
                    </div>
                </div>
            </div>
            <!-- <div class="row">
                <label class="col-sm-2 col-form-label text-center">เอกสารประกอบการร้องเรียน *</label>
                <div class="col-sm-10">
                    <div class="form-group">
                        <span class="btn btn-rose">
                            <input type="file" id="attacthmentInput" name="attacthmentInput" class="form-control-file" placeholder="" aria-describedby="fileHelpId">
                            เลือกไฟล์
                        </span>
                    </div>
                </div>
            </div> -->
        </div>
        <div class="card-footer">
            <div class="col-md-12 text-center">
                <button class="btn btn-warning btn-lg me-5"  onClick="refreshPage()">ยกเลิก</button>
                <button class="btn btn-success btn-lg">ส่งเรื่อง</button>
            </div>
        </div>
    </div>
</form>

<script>
function refreshPage(){
    window.location.reload();
} 


    $("document").ready(() => {
        dataSwitch()
        onSubmit()
    })

    function onSubmit() {
        $("#complaintForm").submit(function(e) {
            e.preventDefault()
            // $(".btn").prop("disabled", true)
            var formData = new FormData(this);
            var dt = new Date();
            var time = dt.getHours() + "" + dt.getMinutes() + "" + dt.getSeconds();
            var token = makeid(2) + time
            formData.append('token', token)
            formData.append('responder', '')
            axios
                .post('makeComplaint', formData)
                .then((res) => {
                    console.log(res.data)
                    swal.fire({
                            type: "success",
                            title: "บันทึกข้อมูลเรียบร้อยแล้ว<br/>TOKEN: " + token,
                            text: "กรุณาจัดเก็บ TOKEN ของท่านเพื่อติดตามเรื่องร้องเรียน"
                        })
                        .then(function() {
                             window.location.href = "/public/makeComplaint";
                        })
                })
        })
    }

    function dataSwitch() {
        $("#dataSwitch").change(() => {
            if ($("#dataSwitch").prop("checked") == true) {
                $("#dataSwitch").prop("checked", true)
                $("#switchText").text('ปกปิด')
            } else {
                $("#dataSwitch").attr("checked", false)
                $("#switchText").text('ไม่ปกปิด')
            }
        })
    }

    function makeid(length) {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() *
                charactersLength));
        }
        return result;
    }



    $("[name='one']").change(function(){ 
    if($(this).val() == "เปิดเผยตัวตน" )
    {
        document.getElementById("complainantName").style.visibility="visible";
        $('.otherprof').slideDown();
        document.getElementById("complainantName").value = "";

    }
    else
    {
        document.getElementById("complainantName").style.visibility="hidden";

         $('.otherprof').slideUp();
         document.getElementById("complainantName").value = "ผู้ร้องเรียนประสงค์ปกปิดตัวตน";

    }
     });
</script>